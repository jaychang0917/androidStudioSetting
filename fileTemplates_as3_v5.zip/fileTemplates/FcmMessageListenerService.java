package ${PACKAGE_NAME}

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.support.v4.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class FcmMessageListenerService : FirebaseMessagingService() {

  /**
   * This method will not call if the app is in background.
   * Fcm will show a notification automatically if in background.
   */
  override fun onMessageReceived(message: RemoteMessage) {
    //extra key-value data sent from server
    val data = message.data
    // show notification if the app is in foreground
    showNotification(message.notification)
  }

  private fun showNotification(notification: RemoteMessage.Notification) {
    val title = notification.title ?: ""
    val content = notification.body
    val hasSound = notification.sound != null

    val intent = Intent(this, MainActivity::class.java)
    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
    val pendingIntent = PendingIntent.getActivity(this, 0, intent,
      PendingIntent.FLAG_ONE_SHOT)

    val notificationBuilder = NotificationCompat.Builder(this)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentTitle(title)
      .setContentText(content)
      .setAutoCancel(true)
      .setContentIntent(pendingIntent)

    if (hasSound) {
      val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
      notificationBuilder.setSound(defaultSoundUri)
    }

    val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    notificationManager.notify(0, notificationBuilder.build())
  }
}
