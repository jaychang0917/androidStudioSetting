package ${PACKAGE_NAME};

import android.util.Log;

import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;
import com.redso.boutircollect.BuildConfig;

import java.util.HashMap;
import java.util.Map;

public class ${NAME} {

  private static final String TAG = ${NAME}.class.getSimpleName();
  private static final ${NAME} INSTANCE = new ${NAME}();

  private FirebaseRemoteConfig remoteConfig;
  private boolean isInitialized;
  private Map<String, Object> defaultSettings;

  private static final String KEY_DISCOVER_DEFAULT_TAB = "collect_discover_default_tab";
  private static final String KEY_SHOW_CNY_2017_UI = "show_cny2017_ui";

  {
    defaultSettings = new HashMap<>();
    defaultSettings.put(KEY_DISCOVER_DEFAULT_TAB, 1);
    defaultSettings.put(KEY_SHOW_CNY_2017_UI, 0);
  }

  private ${NAME}() {
  }

  public static ${NAME} getInstance() {
    return INSTANCE;
  }

  private void initIfNeed() {
    if (isInitialized) {
      return;
    }

    if (remoteConfig == null) {
      remoteConfig = FirebaseRemoteConfig.getInstance();
    }

    FirebaseRemoteConfigSettings settings = new FirebaseRemoteConfigSettings.Builder()
      .setDeveloperModeEnabled(BuildConfig.DEBUG).build();
    remoteConfig.setConfigSettings(settings);

    remoteConfig.setDefaults(defaultSettings);

    isInitialized = true;
  }

  public void fetch() {
    initIfNeed();

    long cacheExpiration = remoteConfig.getInfo().getConfigSettings().isDeveloperModeEnabled() ? 0 : 43200; // default 12 hours

    remoteConfig.fetch(cacheExpiration)
      .addOnCompleteListener(task -> {
        if (task.isSuccessful()) {
          remoteConfig.activateFetched();
          Log.d(TAG, "Remote Config fetched.");
        } else {
          Log.d(TAG, "Fail to fetch Remote Config.");
        }
      });
  }

  public boolean isCNY2017UIEnabled() {
    return remoteConfig.getLong(KEY_SHOW_CNY_2017_UI) == 1;
  }

  public int getDefaultDiscoverTab() {
    return (int) remoteConfig.getLong(KEY_DISCOVER_DEFAULT_TAB);
  }

}
