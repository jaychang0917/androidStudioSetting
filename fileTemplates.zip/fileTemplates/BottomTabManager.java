package ${PACKAGE_NAME};

import android.support.v4.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItemAdapter;
import com.ogaclejapan.smarttablayout.utils.v4.FragmentPagerItems;

public class BottomTabManager {

  private SmartTabLayout tabLayout;
  private ViewPager viewPager;
  private FragmentPagerItemAdapter adapter;

  private BottomTabManager() {
  }

  private enum Tab {
    NOTIFICATION(R.string.TXT_TAB_Notification, R.drawable.state_tab_notification, NotificationFragment.class),
    FRIENDS(R.string.TXT_TAB_Friends, R.drawable.state_tab_friends, FriendsFragment.class),
    HOME(R.string.TXT_TAB_Home, R.drawable.state_tab_home, HomeFragment.class),
    MSG(R.string.TXT_TAB_Inbox, R.drawable.state_tab_inbox, InboxFragment.class),
    CREATE_TOPIC(R.string.TXT_TAB_Create_Topic, R.drawable.state_tab_create_topic, CreateTopicContainerFragment.class);

    int title;
    int icon;
    Class<? extends Fragment> fragment;

    Tab(int title, int icon, Class<? extends Fragment> fragment) {
      this.title = title;
      this.icon = icon;
      this.fragment = fragment;
    }
  }

  public static BottomTabManager init(final BaseActivity activity) {
    final BottomTabManager instance = new BottomTabManager();

    FragmentPagerItems.Creator pages = FragmentPagerItems.with(activity);
    for (int i = 0; i < Tab.values().length; i++) {
      Tab tab = Tab.values()[i];
      pages.add(tab.title, tab.fragment);
    }

    instance.tabLayout = (SmartTabLayout) activity.findViewById(R.id.tabLayout);
    instance.viewPager = (ViewPager) activity.findViewById(R.id.viewPager);
//    instance.viewPager.setOffscreenPageLimit(Tab.values().length);
    instance.adapter = new FragmentPagerItemAdapter(
      activity.getSupportFragmentManager(), pages.create());

    instance.viewPager.setAdapter(instance.adapter);
    instance.tabLayout.setCustomTabView(new SmartTabLayout.TabProvider() {
      @Override
      public View createTabView(ViewGroup container, int position, PagerAdapter adapter) {
        LinearLayout view = (LinearLayout) LayoutInflater.from(container.getContext()).inflate(R.layout.part_tab_item, container, false);
        ImageView imageView = (ImageView) view.findViewById(R.id.tabImageView);
        imageView.setImageResource(Tab.values()[position].icon);
        TextView titleView = (TextView) view.findViewById(R.id.tabTitleView);
        titleView.setText(adapter.getPageTitle(position));
        return view;
      }
    });

    instance.tabLayout.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
      @Override
      public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
      }

      @Override
      public void onPageSelected(int position) {
        instance.onTabSelected(position);
      }

      @Override
      public void onPageScrollStateChanged(int state) {
      }
    });

    instance.tabLayout.setViewPager(instance.viewPager);

    return instance;
  }

  public void selectTab(int pos) {
    viewPager.setCurrentItem(pos);
  }

  public void onTabSelected(int pos) {
    Fragment fragment = adapter.getPage(pos);
    if (fragment instanceof OnTabSelectListener) {
      ((OnTabSelectListener) fragment).onTabSelected(pos);
    } else {
      if (fragment == null) {
        return;
      }

      List<Fragment> childFragments = fragment.getChildFragmentManager().getFragments();
      if (childFragments == null) {
        return;
      }
      for (Fragment child : childFragments) {
        if (child instanceof OnTabSelectListener) {
          ((OnTabSelectListener) child).onTabSelected(pos);
        }
      }
    }
  }

  public void reloadTab(int pos) {
    Fragment fragment = adapter.getPage(pos);
    if (fragment instanceof Reloadable) {
      ((Reloadable) fragment).reload();
    }
  }

  public void setOnTabClickListener(OnTabClickListener onTabClickListener) {
    for (int i = 0; i < Tab.values().length; i++) {
      int toPos = i;
      View tab = tabLayout.getTabAt(i);
      if (onTabClickListener == null) {
        tab.setOnClickListener(null);
      } else {
        tab.setOnClickListener(view -> {
          int fromPos = viewPager.getCurrentItem();
          if (fromPos != toPos) {
            onTabClickListener.onTabClicked(fromPos, toPos);
          }
        });
      }
    }
  }

  public void show() {
    tabLayout.setVisibility(View.VISIBLE);
  }

  public void hide() {
    tabLayout.setVisibility(View.GONE);
  }

  public interface Reloadable {
    void reload();
  }

  public interface OnTabSelectListener {
    void onTabSelected(int pos);
  }

  public interface OnTabClickListener {
    void onTabClicked(int fromPos, int toPos);
  }

}
