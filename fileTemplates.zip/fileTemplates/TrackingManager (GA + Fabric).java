package ${PACKAGE_NAME};

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.flurry.android.FlurryAgent;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.trailwatch.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TrackingManager {
  private static final String TAG = "TrackingManager";
  private static Tracker gaTracker;

  public static void init(Context context) {
    GoogleAnalytics googleAnalytics = GoogleAnalytics.getInstance(context);
    gaTracker = googleAnalytics.newTracker(R.xml.global_tracker);
  }

  public static void logScreen(String screen) {
    Log.i(TAG, "logScreen => " + screen);

    gaTracker.setScreenName(screen);
    gaTracker.send(new HitBuilders.ScreenViewBuilder().build());

    FlurryAgent.onPageView();
  }

  public static void logEvent(String category, String action, String label) {
    Log.i(TAG, "logEvent => " + "category: " + category + " action: " + action + " label: " + label);

    gaTracker.send(new HitBuilders.EventBuilder().setCategory(category).setAction(action).setLabel(label).build());

    Map<String, String> params = new HashMap<>();
    params.put("Event Category", category);
    params.put("Event Label", label);
    FlurryAgent.logEvent(action, params);
  }

  public static void logEvent(String category, String action, LinkedHashMap<String, String> labels) {
    Log.i(TAG, "logEvent => " + "category: " + category + " action: " + action + " labels: " + labels);

    List<String> labelList = new ArrayList<>();
    for (Map.Entry entry : labels.entrySet()) {
      labelList.add(String.format("%1$s: %2$s", entry.getKey(), entry.getValue()));
    }
    String labelsStr = TextUtils.join(", ", labelList);

    System.out.println("labelsStr: " + labelsStr);

    gaTracker.send(new HitBuilders.EventBuilder().setCategory(category).setAction(action).setLabel(labelsStr).build());

    Map<String, String> params = new HashMap<>();
    params.put("Event Category", category);
    params.putAll(labels);
    FlurryAgent.logEvent(action, params);
  }
}
