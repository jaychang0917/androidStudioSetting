package ${PACKAGE_NAME};

import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ${NAME} implements Serializable, Attachment {

  private String url;
  private String id;
  private String thumbnailUrl;

  private ${NAME}() {
  }

  public static ${NAME} fromUrl(String url) {
    ${NAME} youtubeVideo = new ${NAME}();
    youtubeVideo.url = url;
    youtubeVideo.id = youtubeVideo.getId();
    youtubeVideo.thumbnailUrl = youtubeVideo.getThumbnailUrl();
    return youtubeVideo;
  }

  public static ${NAME} fromId(String id) {
    ${NAME} youtubeVideo = new ${NAME}();
    youtubeVideo.id = id;
    youtubeVideo.url = String.format("https://www.youtube.com/watch?v=%1$s", id);
    youtubeVideo.thumbnailUrl = youtubeVideo.getThumbnailUrl();
    return youtubeVideo;
  }

  public String getUrl() {
    return url;
  }

  public String getId() {
    if (id != null) {
      return id;
    }

    String pattern = "^(?:(?:https?:\\/\\/)?(?:www\\.)?)?(youtube(?:-nocookie)?\\.com|youtu\\.be)\\/.*?(?:embed|e|v|watch\\?.*?v=)?\\/?([a-z0-9]+)";
    Pattern compiledPattern = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE);
    Matcher matcher = compiledPattern.matcher(url);
    if (matcher.matches()) {
      return matcher.group(2);
    }

    return null;
  }

  public String getThumbnailUrl() {
    if (thumbnailUrl != null) {
      return thumbnailUrl;
    }

    return String.format("http://img.youtube.com/vi/%1$s/0.jpg", id);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    ${NAME} that = (${NAME}) o;

    return id != null ? id.equals(that.id) : that.id == null;

  }

  @Override
  public int hashCode() {
    return id != null ? id.hashCode() : 0;
  }
}
