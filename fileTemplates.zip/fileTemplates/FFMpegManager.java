package ${PACKAGE_NAME};

import android.content.Context;
import android.util.Log;

import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.LoadBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegNotSupportedException;

import java.io.File;
import java.util.UUID;

import rx.Emitter;
import rx.Observable;

public class ${NAME} {

  private static final String TAG = ${NAME}.class.getSimpleName();
  private static ${NAME} INSTANCE = new ${NAME}();

  private ${NAME}() {
  }

  public static ${NAME} getInstance() {
    return INSTANCE;
  }

  public static void init(Context context) {
    FFmpeg ffmpeg = FFmpeg.getInstance(context.getApplicationContext());
    try {
      ffmpeg.loadBinary(new LoadBinaryResponseHandler() {

        @Override
        public void onStart() {
        }

        @Override
        public void onFailure() {
          Log.e(TAG, "FFmpeg load failed");
        }

        @Override
        public void onSuccess() {
          Log.d(TAG, "FFmpeg load success");
        }

        @Override
        public void onFinish() {}
      });
    } catch (FFmpegNotSupportedException e) {
      Log.e(TAG, "FFmpeg is not supported by device");
    }
  }

}
