package ${PACKAGE_NAME};

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.f2prateek.dart.Dart;
import com.f2prateek.dart.InjectExtra;

import butterknife.BindView;
import butterknife.ButterKnife;
import uk.co.senab.photoview.PhotoView;
import uk.co.senab.photoview.PhotoViewAttacher;

public class PhotoViewerActivity extends AppCompatActivity {

  @BindView(R.id.photoView)
  PhotoView photoView;
  @BindView(R.id.cancelBtnView)
  ImageView cancelBtnView;
  @BindView(R.id.shareBtnView)
  ImageView shareBtnView;
  @BindView(R.id.deleteBtnView)
  ImageView deleteBtnView;

  public static final String EXTRA_IMAGE_URL = "EXTRA_IMAGE_URL";
  public static final String EXTRA_PRODUCT_ID = "EXTRA_PRODUCT_ID";
  private String imageUrl;
  private String productId;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_photo_viewer);
    ButterKnife.bind(this);
    init();
  }
  
  private void init() {
    AppUtils.setStatusBarColor(this, android.R.color.black);
    
    imageUrl = getIntent().getStringExtra(EXTRA_IMAGE_URL);
    productId = getIntent().getStringExtra(EXTRA_PRODUCT_ID);

    Glide.with(this)
      .load(imageUrl)
      .thumbnail(0.1f)
      .into(photoView);

    PhotoViewAttacher mAttacher = new PhotoViewAttacher(photoView);
    mAttacher.update();
  }

  @OnClick(R.id.cancelBtnView)
  void back() {
    finish();
  }

  @OnClick(R.id.shareBtnView)
  void sharePhoto() {
    AppUtils.shareImage(this, "", imageUrl);
  }

  @OnClick(R.id.deleteBtnView)
  void deletePhoto() {

  }
}