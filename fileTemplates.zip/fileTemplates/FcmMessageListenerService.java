package ${PACKAGE_NAME};

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

public class FcmMessageListenerService extends FirebaseMessagingService {

  /** This method will not call if the app is in background.
   *  Fcm will show a notification automatically if in background.
   * */
  @Override
  public void onMessageReceived(RemoteMessage message){
    //extra key-value data sent from server
    Map data = message.getData();
    // show notification if the app is in foreground
    showNotification(message.getNotification());
  }

  private void showNotification(RemoteMessage.Notification notification) {
    String title = notification.getTitle() != null ? notification.getTitle() : "";
    String content = notification.getBody();
    boolean hasSound = notification.getSound() != null;

    Intent intent = new Intent(this, MainActivity.class);
    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
    PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent,
      PendingIntent.FLAG_ONE_SHOT);

    NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentTitle(title)
      .setContentText(content)
      .setAutoCancel(true)
      .setContentIntent(pendingIntent);

    if (hasSound) {
      Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
      notificationBuilder.setSound(defaultSoundUri);
    }

    NotificationManager notificationManager =
      (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

    notificationManager.notify(0, notificationBuilder.build());
  }
}
