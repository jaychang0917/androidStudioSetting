package ${PACKAGE_NAME}

import android.content.Context
import android.os.Handler
import android.support.v4.view.PagerAdapter
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import com.buddigo.buying.app.R
import com.buddigo.buying.app.utils.ImageUtils
import kotlinx.android.synthetic.main.view_gallery_show.view.*

class GalleryShowView : FrameLayout {
  private var loopHandler = Handler()
  var onPageClicked: ((position: Int) -> Unit)? = null
  var isViewMode = false
  var currentPos: Int
    get() = viewPager.currentItem
    set(value) {
      setPosition(value, false)
    }

  constructor(ctx: Context) : this(ctx, null, 0)
  constructor(ctx: Context, attrs: AttributeSet?) : this(ctx, attrs, 0)
  constructor(ctx: Context, attrs: AttributeSet?, defaultStyleAttrs: Int) : super(ctx, attrs, defaultStyleAttrs) {
    LayoutInflater.from(ctx).inflate(R.layout.view_gallery_show, this)
    leftArrowView.setOnClickListener {
      val pos = pageIndicatorView.selection - 1
      setPosition(pos)
    }
    rightArrowView.setOnClickListener {
      val pos = pageIndicatorView.selection + 1
      setPosition(pos)
    }
    viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
      override fun onPageScrollStateChanged(state: Int) {
      }

      override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
      }

      override fun onPageSelected(position: Int) {
        pageIndicatorView.selection = position
      }
    })
  }

  private fun setPosition(pos: Int, needAnimation: Boolean = true) {
    pageIndicatorView.selection = pos
    if (needAnimation) {
      viewPager.currentItem = pos
    } else {
      viewPager.setCurrentItem(pos, false)
    }
  }

  fun setData(data: List<String>, currentPos: Int = 0) {
    val isSinglePhoto = data.size <= 1
    leftArrowView.isGone = isSinglePhoto
    rightArrowView.isGone = isSinglePhoto
    pageIndicatorView.count = data.size
    viewPager.adapter = MyAdapter(context, data)
    setPosition(currentPos)
  }

  fun setIsLoop(value: Boolean, delayMillis: Long = 2000L) {
    if (!value) {
      return
    }

    loopHandler.apply {
      val runnable = object : Runnable {
        override fun run() {
          val attempPos = pageIndicatorView.selection + 1
          val pos = if (attempPos >= viewPager.childCount) 0 else {
            attempPos
          }
          setPosition(pos)
          postDelayed(this, delayMillis)
        }
      }
      postDelayed(runnable, delayMillis)
    }
  }

  private inner class MyAdapter(val context: Context, val data: List<String>) : PagerAdapter() {
    var viewList: List<View>

    init {
      viewList = createPageList()
    }

    override fun instantiateItem(collection: ViewGroup, position: Int): Any {
      val view = viewList[position]
      collection.addView(view)
      return view
    }

    override fun destroyItem(collection: ViewGroup, position: Int, view: Any) {
      collection.removeView(view as View)
    }

    override fun getCount(): Int {
      return viewList.size
    }

    override fun isViewFromObject(view: View, obj: Any): Boolean {
      return view === obj
    }

    override fun getItemPosition(`object`: Any?): Int {
      return POSITION_NONE
    }

    private fun createPageList(): List<View> {
      return data.map { createPageView(it) }
    }

    private fun createPageView(url: String): View {
      val view = if (isViewMode) PhotoView(context) else ImageView(context)
      if (view is PhotoView) {
        PhotoViewAttacher(view).update()
      } else {
        view.scaleType = ImageView.ScaleType.CENTER_CROP
      }
      ImageUtils.load(url, view)
      view.setOnClickListener {
        onPageClicked?.invoke(viewList.indexOf(it))
      }
      return view
    }
  }

  override fun onDetachedFromWindow() {
    super.onDetachedFromWindow()
    loopHandler.removeCallbacksAndMessages(null)
  }
}

class ViewPagerFixed : ViewPager {
  constructor(context: Context) : super(context)
  constructor(context: Context, attrs: AttributeSet) : super(context, attrs)

  override fun onTouchEvent(ev: MotionEvent): Boolean {
    try {
      return super.onTouchEvent(ev)
    } catch (ex: IllegalArgumentException) {
      ex.printStackTrace()
    }

    return false
  }

  override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
    try {
      return super.onInterceptTouchEvent(ev)
    } catch (ex: IllegalArgumentException) {
      ex.printStackTrace()
    }

    return false
  }
}