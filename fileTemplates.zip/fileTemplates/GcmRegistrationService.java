package ${PACKAGE_NAME};

import android.app.IntentService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.google.android.gms.gcm.GcmPubSub;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.google.android.gms.iid.InstanceID;
import java.io.IOException;

public class GcmRegistrationService extends IntentService {
  
  private static final String SENDER_ID = "$Sender_Id";
  
  public GcmRegistrationService() {
    super("GcmRegistrationService");
  }

  @Override
  protected void onHandleIntent(Intent intent) {
    SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

    try {
      InstanceID instanceID = InstanceID.getInstance(this);
      String token = instanceID.getToken(SENDER_ID,
        GoogleCloudMessaging.INSTANCE_ID_SCOPE, null);
      sendRegistrationToServer(token);
      sharedPreferences.edit().putBoolean(GcmManager.IS_GCM_REGISTERED, true).apply();
    } catch (Exception e) {
      sharedPreferences.edit().putBoolean(GcmManager.IS_GCM_REGISTERED, false).apply();
    }
  }

  private void sendRegistrationToServer(String token) {
    // custom implementation for server to send push to specific devices
  }

}