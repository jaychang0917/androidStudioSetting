package ${PACKAGE_NAME};

import android.util.Log;

public class ${NAME} {

  private static final String TAG = "Transformer";
  private static boolean debug = true;

  private ${NAME}() {
  }

  public static void logDebug(String tag, String msg) {
    if (debug) {
      Log.d(tag, msg);
    }
  }

  public static void logError(String tag, String msg) {
    if (debug) {
      Log.e(tag, msg);
    }
  }

  public static void logDebug(String msg) {
    logDebug(TAG, msg);
  }

  public static void logError(String msg) {
    logError(TAG, msg);
  }
  
}