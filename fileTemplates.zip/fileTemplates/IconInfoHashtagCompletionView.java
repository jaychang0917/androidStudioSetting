package ${PACKAGE_NAME};

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.jaychang.toolbox.util.AppUtils;
import com.jaychang.toolbox.util.SimpleTextChangedListener;
import com.rsl.butterfly.R;
import com.rsl.butterfly.data.model.Hashtag;
import com.tokenautocomplete.TokenCompleteTextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import java8.util.stream.Collectors;
import java8.util.stream.StreamSupport;

public class ${NAME} extends RelativeLayout {

  @BindView(R.id.iconView)
  ImageView iconView;
  @BindView(R.id.titleView)
  TextView titleView;
  @BindView(R.id.hashtagCompletionView)
  HashtagCompletionView hashtagCompletionView;

  private static final int MAX_HASHTAG_SIZE = 5;
  private static final int FILTER_THRESHOLD = 1;
  private static final char[] SPLITERS =  new char[] {' ', ','};
  private String title;
  private String hint;
  private int icon;
  private HashtagCompletionAdapter adapter;

  public ${NAME}(Context context) {
    this(context, null);
  }

  public ${NAME}(Context context, AttributeSet attrs) {
    this(context, attrs, 0);
  }

  public ${NAME}(Context context, AttributeSet attrs, int defStyle) {
    super(context, attrs, defStyle);
    LayoutInflater.from(context).inflate(R.layout.view_icon_info_hashtag_completion, this);
    ButterKnife.bind(this);
    TypedArray typedArray = context.getTheme().obtainStyledAttributes(attrs, R.styleable.IconInfoEditTextView, defStyle, 0);
    title = typedArray.getString(R.styleable.IconInfoEditTextView_iie_Title);
    hint = typedArray.getString(R.styleable.IconInfoEditTextView_iie_Hint);
    icon = typedArray.getResourceId(R.styleable.IconInfoEditTextView_iie_Icon, 0);
    typedArray.recycle();

    init();
  }

  private void init() {
    if (!TextUtils.isEmpty(title)) {
      setTitle(title);
    }
    if (!TextUtils.isEmpty(hint)) {
      setHint(hint);
    }
    if (icon != 0) {
      setIcon(icon);
    }

    setOnClickListener(view -> {
      hashtagCompletionView.requestFocus();
      AppUtils.showKeyboard(hashtagCompletionView);
    });

    hashtagCompletionView.setThreshold(FILTER_THRESHOLD);
    hashtagCompletionView.setSplitChar(SPLITERS);
    hashtagCompletionView.setTokenListener(new TokenCompleteTextView.TokenListener<Hashtag>() {
      @Override
      public void onTokenAdded(Hashtag token) {
        checkHashtagCount();
      }

      @Override
      public void onTokenRemoved(Hashtag token) {
        checkHashtagCount();
      }
    });

    adapter = new HashtagCompletionAdapter(getContext(), new ArrayList<>());
    hashtagCompletionView.setAdapter(adapter);
  }

  private void checkHashtagCount() {
    if (getHashtags().size() >= MAX_HASHTAG_SIZE) {
      hashtagCompletionView.setEnabled(false);
    } else {
      hashtagCompletionView.setEnabled(true);
    }
  }

  public void setTitle(String title) {
    titleView.setText(title);
  }

  public void setHint(String hint) {
    hashtagCompletionView.setHint(hint);
  }

  public void setIcon(int icon) {
    iconView.setImageResource(icon);
  }

  public void setHashtagsSource(List<Hashtag> hashtags) {
    adapter.clear();
    adapter.addAll(hashtags);
    adapter.notifyDataSetChanged();
  }

  public List<Hashtag> getHashtags() {
    return StreamSupport.stream(hashtagCompletionView.getObjects())
      .map(hashtag -> new Hashtag(hashtag.name.replace("#", "")))
      .collect(Collectors.toList());
  }

  public void setOnTextChangeListener(SimpleTextChangedListener listener) {
    hashtagCompletionView.addTextChangedListener(listener);
  }

  public static class HashtagCompletionAdapter extends ArrayAdapter<Hashtag> {

    public HashtagCompletionAdapter(Context context, List<Hashtag> objects) {
      super(context, R.layout.view_hashtag_row_with_count, objects);
    }

    @Override
    public View getView(int pos, View view, ViewGroup parent) {
      Hashtag hashtag = getItem(pos);

      ViewHolder viewHolder;

      if (view == null) {
        view = LayoutInflater.from(getContext()).inflate(R.layout.view_hashtag_row_with_count, parent, false);
        viewHolder = new ViewHolder(view);
        view.setTag(viewHolder);
      } else {
        viewHolder = (ViewHolder) view.getTag();
      }

      viewHolder.hashTagView.setText(hashtag.name);
      viewHolder.countView.setText(hashtag.count + " " + getContext().getString(R.string.TXT_TOPIC_Topic));

      return view;
    }

    static class ViewHolder {
      @BindView(R.id.hashTagView)
      TextView hashTagView;
      @BindView(R.id.countView)
      TextView countView;

      ViewHolder(View view) {
        ButterKnife.bind(this, view);
      }
    }
  }

}
