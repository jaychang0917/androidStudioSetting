package ${PACKAGE_NAME};

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.rsl.butterfly.R;

import java.util.List;

public class ${NAME} {

  private TextView titleView;
  private ImageView closeView;
  private LinearLayout itemContainerLayout;
  private TextView bottomView;

  private MaterialDialog dialog;
  private Context context;
  private int title = -1;
  private List<String> keys;
  private List<String> values;
  private int bottomText = -1;
  private OnItemClickListener onItemClickListener;

  private ${NAME}(Context context) {
    this.context = context;
    this.dialog = new MaterialDialog.Builder(context)
      .customView(R.layout.dialog_list, false)
      .build();

    LinearLayout rootView = (LinearLayout) dialog.getCustomView();
    titleView = (TextView) rootView.findViewById(R.id.titleView);
    itemContainerLayout = (LinearLayout) rootView.findViewById(R.id.itemContainerLayout);
    bottomView = (TextView)rootView.findViewById(R.id.bottomView);
    closeView = (ImageView)rootView.findViewById(R.id.closeView);
  }

  public static ${NAME} create(Context context) {
    return new ${NAME}(context);
  }

  public ${NAME} title(int title) {
    this.title = title;
    return this;
  }

  public ${NAME} keys(List<String> keys) {
    this.keys = keys;
    return this;
  }

  public ${NAME} values(List<String> values) {
    this.values = values;
    return this;
  }

  public ${NAME} bottomText(int bottomText) {
    this.bottomText = bottomText;
    return this;
  }

  public ${NAME} onItemClickListener(OnItemClickListener onItemClickListener) {
    this.onItemClickListener = onItemClickListener;
    return this;
  }

  public MaterialDialog build() {
    if (title != -1) {
      titleView.setText(title);
    } else {
      titleView.setVisibility(View.GONE);
    }

    for (String item : values) {
      TextView itemView = (TextView) LayoutInflater.from(context).inflate(R.layout.dialog_list_item, itemContainerLayout, false);
      itemView.setText(item);
      if (onItemClickListener != null) {
        itemView.setOnClickListener(view -> {
          dialog.dismiss();
          onItemClickListener.onItemClicked(keys.get(values.indexOf(item)), item);
        });
      }
      itemContainerLayout.addView(itemView);
    }

    if (bottomText != -1) {
      bottomView.setText(bottomText);
    } else {
      bottomView.setVisibility(View.GONE);
    }

    bottomView.setOnClickListener(view -> dialog.dismiss());
    closeView.setOnClickListener(view -> dialog.dismiss());

    return dialog;
  }

  public interface OnItemClickListener {
    void onItemClicked(String key, String value);
  }

}