package ${PACKAGE_NAME}

class ${NAME} : BaseActivity(), GoogleMap.OnMarkerClickListener {

  companion object {
    private val CODE_LOCATION_PERMISSION = 1
    private val DEFAULT_MAP_ZOOM = 12f
    private val DEFAULT_LOCATION = LatLng(22.2824673, 114.1615726)
  }

  private lateinit var googleMap: GoogleMap
  private var isMapInitialized = false

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.your_layout)
    requestPermissionIfNeed()
  }

  private fun requestPermissionIfNeed() {
    if (ContextCompat.checkSelfPermission(this, PERMISSION_ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
      setupMapViewIfNeed()
    } else {
      ActivityCompat.requestPermissions(this, arrayOf(PERMISSION_ACCESS_FINE_LOCATION), CODE_LOCATION_PERMISSION)
    }
  }

  override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
    if (requestCode == CODE_LOCATION_PERMISSION && grantResults.isNotEmpty()
      && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
      setupMapViewIfNeed()
    }
  }

  @SuppressLint("MissingPermission")
  private fun setupMapViewIfNeed() {
    if (isMapInitialized) {
      reloadMapView()
      return
    }

    val mapFragment = supportFragmentManager.findFragmentById(R.id.mapFragment) as ScrollableGoogleMapFragment
    mapFragment.handleScroll(scrollView)
    mapFragment.getMapAsync { map ->
      googleMap = map
      map.uiSettings.isMapToolbarEnabled = false
      map.uiSettings.isMyLocationButtonEnabled = true
      map.isMyLocationEnabled = true

      map.moveCamera(CameraUpdateFactory.newLatLngZoom(DEFAULT_LOCATION, DEFAULT_MAP_ZOOM))

      map.setOnMarkerClickListener(this)
      map.setInfoWindowAdapter(object: GoogleMap.InfoWindowAdapter {
        override fun getInfoContents(p0: Marker?): View? = null

        override fun getInfoWindow(marker: Marker): View? {
          val view = LayoutInflater.from(this@${NAME}).inflate(R.layout.view_marker_info_window, null)
          view.textView.text = marker.title
          return view
        }

      })

      reloadMapView()

      isMapInited = true
    }
  }
  
  override fun onMarkerClick(marker: Marker): Boolean {
    return false
  }

  private fun reloadMapView() {
    val region = googleMap.projection.visibleRegion
    val northEast = region.farRight
    val center = googleMap.cameraPosition.target
    val radius = SphericalUtil.computeDistanceBetween(center, northEast)
    // todo load api
  }
  
  private fun bindMapMarkers(data: List<Object>) {
    googleMap.addMarker(MarkerOptions().position(MELBOURNE).icon(BitmapDescriptorFactory.fromResource(R.drawable.marker)))
  }

}