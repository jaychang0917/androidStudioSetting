package ${PACKAGE_NAME}

import android.content.Context
import android.graphics.Color
import android.support.design.widget.BottomSheetBehavior
import android.support.design.widget.CoordinatorLayout
import android.support.v4.widget.NestedScrollView
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import com.buddigo.buying.app.R
import com.buddigo.buying.app.utils.backgroundColor
import com.jaychang.extensions.util.dpToPx

// must as child of CoordinatorLayout
open class BottomInfoView : NestedScrollView {
  protected val behavior = BottomSheetBehavior<View>()
  var dimLayer: View? = null
  var onSlide: ((offset: Float) -> Unit)? = null
  var onStateChanged: ((newState: Int) -> Unit)? = null

  constructor(ctx: Context) : this(ctx, null, 0)
  constructor(ctx: Context, attrs: AttributeSet?) : this(ctx, attrs, 0)
  constructor(ctx: Context, attrs: AttributeSet?, defaultStyleAttrs: Int) : super(ctx, attrs, defaultStyleAttrs)

  override fun onAttachedToWindow() {
    super.onAttachedToWindow()
    (layoutParams as CoordinatorLayout.LayoutParams).behavior = behavior

    behavior.setBottomSheetCallback(object: BottomSheetBehavior.BottomSheetCallback() {
      override fun onSlide(bottomSheet: View, slideOffset: Float) {
        dimLayer?.visibility = View.VISIBLE
        dimLayer?.alpha = slideOffset
        onSlide?.invoke(slideOffset)
      }

      override fun onStateChanged(bottomSheet: View, newState: Int) {
        onStateChanged?.invoke(newState)
        if (newState == BottomSheetBehavior.STATE_COLLAPSED) {
          dimLayer?.visibility = View.GONE
        }
      }
    })
  }

  fun expand() {
    behavior.state = BottomSheetBehavior.STATE_EXPANDED
  }

  fun collapse() {
    behavior.state = BottomSheetBehavior.STATE_COLLAPSED
  }

  fun toggle() {
    if (behavior.state == BottomSheetBehavior.STATE_EXPANDED) {
      collapse()
    } else {
      expand()
    }
  }

  fun setIsHideable(value: Boolean) {
    behavior.isHideable = value
  }

  fun setPeekHeight(value: Int) {
    behavior.peekHeight = value
  }
}