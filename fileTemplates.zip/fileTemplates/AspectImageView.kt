package ${PACKAGE_NAME}

import android.content.Context
import android.util.AttributeSet
import android.widget.ImageView
import futuregain.futuregain.R

class ${NAME}: ImageView {
  var widthRatio = -1
  var heightRatio = -1

  constructor(ctx: Context, attrs: AttributeSet? = null, defaultStyleAttrs: Int = 0) : super(ctx, attrs, defaultStyleAttrs) {
    val typedArray = context.theme.obtainStyledAttributes(attrs, R.styleable.AspectImageView, defaultStyleAttrs, 0)
    widthRatio = typedArray.getInt(R.styleable.${NAME}_clh_width_ratio, -1)
    heightRatio = typedArray.getInt(R.styleable.${NAME}_clh_height_ratio, -1)
    typedArray.recycle()
  }

  override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
    super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    if (widthRatio != -1 && heightRatio != -1) {
      val newHeight = measuredWidth * heightRatio / widthRatio
      setMeasuredDimension(measuredWidth, newHeight)
    }
  }
}