package ${PACKAGE_NAME};

import android.app.application;

import com.facebook.stetho.Stetho;
import com.jakewharton.threetenabp.AndroidThreeTen;
import com.jaychang.toolbox.Toolbox;
import com.orhanobut.logger.Logger;
import com.rsl.butterfly.BuildConfig;
import com.rsl.butterfly.data.local.DatabaseManager;
import com.uphyca.stetho_realm.RealmInspectorModulesProvider;

public class App extends application {

  @Override
  public void onCreate() {
    super.onCreate();
    Logger.init("logger").methodCount(0).hideThreadInfo();
    
    Toolbox.init(this);

    AndroidThreeTen.init(this);

    DatabaseManager.init(this);

    if (BuildConfig.DEBUG) {
      Stetho.initialize(
        Stetho.newInitializerBuilder(this)
          .enableWebKitInspector(RealmInspectorModulesProvider.builder(this).build())
          .build());
    }
    
    CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
      .setDefaultFontPath("fonts/Roboto-RobotoRegular.ttf")
      .setFontAttrId(R.attr.fontPath)
      .build());
  }
}
