package ${PACKAGE_NAME}

import android.net.http.SslError
import android.os.Bundle
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import com.mindbeauty.app.R
import kotlinx.android.synthetic.main.activity_webpage.*

class ${NAME} : BaseActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_webpage)
    
    CookieManager.getInstance().removeSessionCookie()
    webView.settings.javaScriptEnabled = true
    webView.webViewClient = object : WebViewClient() {
      override fun shouldInterceptRequest(view: WebView, url: String): WebResourceResponse? {
        if (url.contains("cancel")) {
          setResult(Activity.RESULT_CANCELED)
          finish()
          return WebResourceResponse("application/json", "utf-8", null)
        }

        return null
      }
    }
    webView.loadUrl("url")
  }
}
