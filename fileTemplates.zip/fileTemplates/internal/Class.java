public class ${NAME} {
  #[[$END$]]#
}
