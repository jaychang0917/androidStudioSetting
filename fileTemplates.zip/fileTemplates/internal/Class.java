public class ${NAME} {

}
