package com.buddigo.selling.app.widgets

import android.content.Context
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ScrollView
import com.google.android.gms.maps.SupportMapFragment

class ScrollableGoogleMapFragment : SupportMapFragment() {
  var scrollView: ScrollView? = null

  override fun onCreateView(layoutInflater: LayoutInflater, viewGroup: ViewGroup?, savedInstance: Bundle?): View? {
    val layout = super.onCreateView(layoutInflater, viewGroup, savedInstance)
    val frameLayout = TouchableWrapper(context)
    frameLayout.setBackgroundColor(ContextCompat.getColor(context, android.R.color.transparent))
    (layout as ViewGroup).addView(frameLayout,
      ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    return layout
  }

  fun handleScroll(scrollView: ScrollView) {
    this.scrollView = scrollView
  }

  fun handleScroll(appBarLayout: AppBarLayout) {
    val params = appBarLayout.layoutParams as CoordinatorLayout.LayoutParams
    val behavior = params.behavior as AppBarLayout.Behavior
    behavior.setDragCallback(object : AppBarLayout.Behavior.DragCallback() {
      override fun canDrag(appBarLayout: AppBarLayout): Boolean {
        return false
      }
    })
  }

  inner class TouchableWrapper(context: Context) : FrameLayout(context) {
    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
      if (scrollView == null) {
        return super.dispatchTouchEvent(event)
      }
      when (event.action) {
        MotionEvent.ACTION_DOWN, MotionEvent.ACTION_UP -> {
          scrollView?.requestDisallowInterceptTouchEvent(true)
        }
      }
      return super.dispatchTouchEvent(event)
    }
  }
}