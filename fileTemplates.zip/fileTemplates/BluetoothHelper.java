package ${PACKAGE_NAME};

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import com.caminotoys.transformer.av.AudioManagerHelper;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;

import rx.Emitter;
import rx.Observable;

import static android.bluetooth.BluetoothDevice.TRANSPORT_LE;
import static android.bluetooth.BluetoothGatt.GATT_SUCCESS;
import static android.bluetooth.BluetoothProfile.STATE_CONNECTED;
import static android.bluetooth.BluetoothProfile.STATE_DISCONNECTED;
import static ${PACKAGE_NAME}.${NAME}.QueueItemType.ReadCharacteristic;
import static ${PACKAGE_NAME}.${NAME}.QueueItemType.WriteCharacteristic;

public class BluetoothHelper {

  public interface Callback {
    void onBluetoothOn();
    void onBluetoothOff();
    void onDeviceClassicConnected(BluetoothDevice device);
    void onDeviceClassicDisconnected(BluetoothDevice device);
    void onDeviceBleConnected(BluetoothDevice device);
    void onDeviceBleDisconnected();
  }

  public static final String TAG = ${NAME}.class.getSimpleName();
  @SuppressLint("StaticFieldLeak")
  private static ${NAME} INSTANCE = new ${NAME}();

  private Context appContext;
  private BluetoothAdapter bluetoothAdapter;
  private BluetoothGatt bluetoothGatt;
  private String deviceAddress;
  private boolean isBleConnected;
  private boolean stopReconnect;
  private List<String> deviceNames;
  private Callback callback;

  private Queue<TransactionQueueItem> transactionQueue = new LinkedList<>();
  private boolean isTxQueueProcessing = false;

  private ${NAME}() {
  }

  public static ${NAME} getInstance() {
    return INSTANCE;
  }

  public static void init(Context context, List<String> deviceNames, Callback callback) {
    INSTANCE.appContext = context.getApplicationContext();
    INSTANCE.bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    INSTANCE.registerBluetoothOnOffStateChangeReceiver();
    INSTANCE.registerDeviceConnectionStateChangeReceiver();
    INSTANCE.deviceNames = new ArrayList<>(deviceNames);
    INSTANCE.callback = callback;
  }

  public static void init(Context context, List<String> deviceNames) {
    init(context, deviceNames, null);
  }

  private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
    @Override
    public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
      super.onConnectionStateChange(gatt, status, newState);
      Log.d(TAG, "onConnectionStateChange received: " + status);

      if (status == GATT_SUCCESS) {
        if (newState == STATE_CONNECTED) {
          Log.d(TAG, "connection state change to Connected, try to discover services");
          bluetoothGatt.discoverServices();
        } else if (newState == STATE_DISCONNECTED) {
          Log.d(TAG, "connection state change to Disconnected, close ble connection");
          disconnectBle();
        }
      } else {
        reconnect();
      }
    }

    @Override
    public void onServicesDiscovered(BluetoothGatt gatt, int status) {
      super.onServicesDiscovered(gatt, status);
      Log.d(TAG, "service discovered, status: " + status);
      if (status == GATT_SUCCESS) {
        isBleConnected = true;
        if (callback != null) {
          callback.onDeviceBleConnected(gatt.getDevice());
        }
      } else {
        reconnect();
      }
    }

    @Override
    public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
      super.onCharacteristicRead(gatt, characteristic, status);
      Log.d(TAG, "onCharacteristicRead, status: " + status);
      if (status != GATT_SUCCESS) {
        reconnect();
      }
    }

    @Override
    public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
      super.onCharacteristicWrite(gatt, characteristic, status);
      Log.d(TAG, "onCharacteristicWrite, status: " + status);
      if (status == GATT_SUCCESS) {
        processTransactionQueue();
      } else {
        reconnect();
      }
    }
  };

  private void reconnect() {
    if (stopReconnect) {
      Log.d(TAG, "Stop reconnect.");
      return;
    }

    Log.d(TAG, "reconnect");
    disconnectBle();
    connectBle(deviceAddress);
  }

  public boolean connectBle(String bluetoothDeviceAddress) {
    stopReconnect = false;

    if (bluetoothDeviceAddress == null) {
      Log.d(TAG, "Unspecified address.");
      return false;
    }

    if (bluetoothGatt != null) {
      Log.d(TAG, "Trying to use an existing mBluetoothGatt for connection.");
      return bluetoothGatt.connect();
    }

    final BluetoothDevice device = bluetoothAdapter.getRemoteDevice(bluetoothDeviceAddress);
    if (device == null) {
      Log.d(TAG, "Device not found. Unable to connectBle.");
      return false;
    }

    if (Build.VERSION.SDK_INT >= 23) {
      bluetoothGatt = device.connectGatt(appContext, false, gattCallback, TRANSPORT_LE);
    } else {
      bluetoothGatt = device.connectGatt(appContext, false, gattCallback);
    }

    Log.d(TAG, "Trying to create a new connection");

    return true;
  }

  public void disconnectBle() {
    if (bluetoothGatt != null) {
      bluetoothGatt.disconnect();
      bluetoothGatt.close();
      bluetoothGatt = null;
      isBleConnected = false;
      if (callback != null) {
        callback.onDeviceBleDisconnected();
      }
      Log.d(TAG, "bluetoothGatt closed");
    }
  }

  public void stopReconnect() {
    stopReconnect = true;
  }

  private boolean writeCharacteristic(UUID serviceUUID, UUID characteristicUUID, byte[] data) {
    BluetoothGattService service = bluetoothGatt.getService(serviceUUID);

    if (service == null) {
      Log.d(TAG, "No service");
      return false;
    }

    BluetoothGattCharacteristic characteristic = service.getCharacteristic(characteristicUUID);

    if (characteristic == null) {
      Log.d(TAG, "No characteristic");
      return false;
    }

    characteristic.setValue(data);

    return bluetoothGatt.writeCharacteristic(characteristic);
  }

  private boolean readCharacteristic(UUID serviceUUID, UUID characteristicUUID) {
    BluetoothGattService service = bluetoothGatt.getService(serviceUUID);

    BluetoothGattCharacteristic characteristic = service.getCharacteristic(characteristicUUID);

    return bluetoothGatt.readCharacteristic(characteristic);
  }

  private void registerBluetoothOnOffStateChangeReceiver() {
    Log.d(TAG, "Register bluetooth on / off state change receiver");
    appContext.registerReceiver(new BroadcastReceiver() {
      @Override
      public void onReceive(Context context, Intent intent) {
        int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1);
        if (state == BluetoothAdapter.STATE_ON) {
          if (callback != null) {
            callback.onBluetoothOn();
          }
          Log.d(TAG, "Bluetooth is turn on");
        } else if (state == BluetoothAdapter.STATE_OFF) {
          if (callback != null) {
            callback.onBluetoothOff();
          }
          Log.d(TAG, "Bluetooth is turn off");
        }
      }
    }, new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED));
  }

  /**
   * - ACTION_CONNECTION_STATE_CHANGED is not working in Android 7, so we should use ACTION_ACL_CONNECTED and ACTION_ACL_DISCONNECTED .
   * - ACTION_ACL_DISCONNECTED will be call when app lost focus(e.g. back to home screen, permission dialog shows up, etc), so we need to
   * check if the profile is really off.
   * */
  private void registerDeviceConnectionStateChangeReceiver() {
    Log.d(TAG, "Register bluetooth speaker connection state change receiver");
    appContext.registerReceiver(new BroadcastReceiver() {
      @Override
      public void onReceive(Context context, Intent intent) {
        if (!isDevicePaired()) {
          return;
        }

        BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
        deviceAddress = device.getAddress();

        if (callback != null) {
          callback.onDeviceClassicConnected(device);
        }
      }
    }, new IntentFilter(BluetoothDevice.ACTION_ACL_CONNECTED));

    appContext.registerReceiver(new BroadcastReceiver() {
      @Override
      public void onReceive(Context context, Intent intent) {
        if (!isDevicePaired()) {
          return;
        }

        boolean isA2dpOn = AudioManagerHelper.getInstance(appContext).getAudioManager().isBluetoothA2dpOn();

        if (!isA2dpOn && callback != null) {
          BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
          callback.onDeviceClassicDisconnected(device);
        }
      }
    }, new IntentFilter(BluetoothDevice.ACTION_ACL_DISCONNECTED));
  }

  private boolean isDevicePaired(String deviceName) {
    for (BluetoothDevice device : getPairedDevices()) {
      if (deviceName.equals(device.getName())) {
        return true;
      }
    }

    return false;
  }

  private boolean isDevicePaired() {
    for (BluetoothDevice device : getPairedDevices()) {
      if (isOurDevice(device)) {
        return true;
      }
    }

    return false;
  }

  private boolean isOurDevice(@NonNull BluetoothDevice device) {
    return deviceNames.contains(device.getName());
  }

  private Set<BluetoothDevice> getPairedDevices() {
    return bluetoothAdapter.getBondedDevices();
  }

  /**
   * Callback is only be called when bluetooth is on
   * */
  public Observable<List<BluetoothDevice>> getConnectedDevices() {
    return Observable.create(emitter -> {
      BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
      BluetoothProfile.ServiceListener listener = new BluetoothProfile.ServiceListener() {
        public void onServiceConnected(int profile, BluetoothProfile proxy) {
          if (profile == BluetoothProfile.A2DP) {
            BluetoothA2dp a2dp = (BluetoothA2dp) proxy;
            emitter.onNext(a2dp.getConnectedDevices());
            emitter.onCompleted();
            bluetoothAdapter.closeProfileProxy(BluetoothProfile.A2DP, a2dp);
          } else {
            emitter.onNext(new ArrayList<>());
            emitter.onCompleted();
          }
        }

        public void onServiceDisconnected(int profile) {
        }
      };
      bluetoothAdapter.getProfileProxy(appContext, listener, BluetoothProfile.A2DP);
    }, Emitter.BackpressureMode.BUFFER);
  }

  public Observable<Boolean> isDeviceClassicConnected(String deviceName) {
    if (!isDevicePaired(deviceName)) {
      return Observable.just(false);
    }

    return Observable.create(emitter -> {
      BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
      BluetoothProfile.ServiceListener listener = new BluetoothProfile.ServiceListener() {
        public void onServiceConnected(int profile, BluetoothProfile proxy) {
          if (profile == BluetoothProfile.A2DP) {
            BluetoothA2dp a2dp = (BluetoothA2dp) proxy;
            List<BluetoothDevice> devices = a2dp.getConnectedDevices();
            boolean isConnected = false;
            for (BluetoothDevice device : devices) {
              if (deviceName.equals(device.getName())) {
                isConnected = true;
              }
            }
            emitter.onNext(isConnected);
            emitter.onCompleted();
            bluetoothAdapter.closeProfileProxy(BluetoothProfile.A2DP, a2dp);
          } else {
            emitter.onNext(false);
            emitter.onCompleted();
          }
        }

        public void onServiceDisconnected(int profile) {
        }
      };
      bluetoothAdapter.getProfileProxy(appContext, listener, BluetoothProfile.A2DP);
    }, Emitter.BackpressureMode.BUFFER);
  }

  public boolean isBleConnected() {
    return isBleConnected;
  }

  public boolean isBluetoothOn() {
    return bluetoothAdapter.isEnabled();
  }

  @Nullable
  public BluetoothDevice getDevice(String device) {
    for (BluetoothDevice d : getPairedDevices()) {
      if (device.equals(d.getName())) {
        return d;
      }
    }
    return null;
  }

  public void queueWriteDataToCharacteristic(UUID serviceUUID, UUID characteristicUUID, final byte[] dataToWrite) {
    TransactionQueueItem transactionQueueItem = new TransactionQueueItem();
    transactionQueueItem.serviceUUID = serviceUUID;
    transactionQueueItem.characteristicUUID = characteristicUUID;
    transactionQueueItem.dataToWrite = dataToWrite;
    transactionQueueItem.type = WriteCharacteristic;
    addToTransactionQueue(transactionQueueItem);
  }

  public void queueReadCharacteristicValue(UUID serviceUUID, UUID characteristicUUID) {
    TransactionQueueItem transactionQueueItem = new TransactionQueueItem();
    transactionQueueItem.serviceUUID = serviceUUID;
    transactionQueueItem.characteristicUUID = characteristicUUID;
    transactionQueueItem.type = ReadCharacteristic;
    addToTransactionQueue(transactionQueueItem);
  }

  private void addToTransactionQueue(TransactionQueueItem transactionQueueItem) {
    transactionQueue.add(transactionQueueItem);

    // If there is no other transmission processing, go do this one!
    if (!isTxQueueProcessing) {
      processTransactionQueue();
    }
  }

  private void processTransactionQueue() {
    if (transactionQueue.size() <= 0) {
      isTxQueueProcessing = false;
      return;
    }

    isTxQueueProcessing = true;
    TransactionQueueItem txQueueItem = transactionQueue.remove();
    switch (txQueueItem.type) {
      case WriteCharacteristic:
        writeCharacteristic(txQueueItem.serviceUUID, txQueueItem.characteristicUUID, txQueueItem.dataToWrite);
        break;
      case ReadCharacteristic:
        readCharacteristic(txQueueItem.serviceUUID, txQueueItem.characteristicUUID);
        break;
    }
  }

  /**
   * Transaction transactionQueue
   */
  private static class TransactionQueueItem {
    UUID serviceUUID;
    UUID characteristicUUID;
    byte[] dataToWrite;
    QueueItemType type;
  }

  enum QueueItemType {
    ReadCharacteristic,
    WriteCharacteristic
  }

}
