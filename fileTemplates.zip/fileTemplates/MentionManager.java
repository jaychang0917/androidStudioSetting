package ${PACKAGE_NAME};

import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.jaychang.toolbox.NRichText;
import com.jaychang.toolbox.Range;
import com.jaychang.toolbox.util.SimpleTextChangedListener;
import com.jaychang.toolbox.util.StringUtils;
import com.rsl.butterfly.R;
import com.rsl.butterfly.data.model.User;
import com.rsl.butterfly.features.topic.widget.MentionView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import java8.util.stream.Collectors;
import java8.util.stream.StreamSupport;

import static java8.util.stream.StreamSupport.stream;

public class ${NAME} {

  private ViewGroup contentPanel;
  private EditText contentView;
  private MentionView mentionView;
  private List<Mention> mentions;
  private SimpleTextChangedListener textChangedListenerForMention;

  public static ${NAME} init(ViewGroup contentPanel, EditText contentView, MentionView mentionView) {
    ${NAME} instance = new ${NAME}();

    instance.contentPanel = contentPanel;
    instance.contentView = contentView;
    instance.mentionView = mentionView;
    instance.mentions = new ArrayList<>();
    instance.textChangedListenerForMention = new SimpleTextChangedListener() {
      @Override
      public void onTextChanged(CharSequence s, int start, int before, int count) {
        instance.handleTextChangeForMention(count);
      }
    };

    instance.mentionView.init();

    instance.mentionView.setCallback(new MentionView.Callback() {
      @Override
      public void onCancel(MentionView view) {
        instance.showContentView();
        instance.removeTextChangeListenerForMention();
        instance.copyInfoToContentView();
        instance.addTextChangeListenerForMention();
      }

      @Override
      public void onUserSelected(MentionView view, User user) {
        instance.showContentView();
        instance.removeTextChangeListenerForMention();
        instance.copyInfoToContentView();
        instance.addMentionTagToContent(user);
        instance.addTextChangeListenerForMention();
      }
    });

    return instance;
  }

  public void handle() {
    contentView.addTextChangedListener(textChangedListenerForMention);
  }

  public void release() {
    contentView.removeTextChangedListener(textChangedListenerForMention);
    textChangedListenerForMention = null;
    mentionView.release();
    contentView.getText().clear();
    mentions.clear();
  }

  public String getMentionUserIds() {
    List<String> userIdList = StreamSupport.stream(getMentions())
      .map(mention -> mention.user.userId)
      .collect(Collectors.toList());

    return TextUtils.join(",", userIdList);
  }

  public void setMentions(List<Mention> mentions) {
    this.mentions = mentions;
  }

  public List<Mention> getMentions() {
    return mentions;
  }

  private void handleTextChangeForMention(int count) {
    updateMentionTagPos();

    boolean isDelete = count == 0;

    if (isCursorInMiddleOfMentionTag()) {
      removeMentionTag(getMentionTagAtCursorPos());
    }

    if (needShowMentionView()) {
      copyInfoToMentionView();
      showMentionView();
    }

    if (isDelete && isDeleteLastCharOfMentionTag()) {
      removeTextChangeListenerForMention();
      removeMentionTagFromContent(getMentionTagBeforeCursor());
      addTextChangeListenerForMention();
    }
  }

  private void updateMentionTagPos() {
    if (mentions.size() <= 0) {
      return;
    }

    CharSequence content = contentView.getText();

    for (Mention tag : mentions) {
      List<Integer> indexes = StringUtils.indexesOf(content.toString(), "@" + tag.user.name);
      if (indexes.size() <= 0) {
        continue;
      }
      int from = indexes.get(getMentionTagOffset(tag));
      int to = from + tag.user.name.length();
      tag.range.from = from;
      tag.range.to = to;
      tag.posUpdated = true;
    }

    resetAllMentionTagPosUpdateState();
  }

  private void resetAllMentionTagPosUpdateState() {
    for (Mention mention : mentions) {
      mention.posUpdated = false;
    }
  }

  private int getMentionTagOffset(Mention tag) {
    int offset = 0;

    for (Mention otherTag : mentions) {
      if (tag == otherTag) {
        continue;
      }
      if (tag.user.name.equals(otherTag.user.name) && otherTag.posUpdated) {
        offset = offset + 1;
      }
    }

    return offset;
  }

  private void copyInfoToMentionView() {
    mentionView.setContent(contentView.getText());
    mentionView.setCursorPos(getCursorPos());
    mentionView.setQueryPrefix(getTextBetweenAtSignAndCursor());
  }

  private void copyInfoToContentView() {
    contentView.setText(mentionView.getContent());
    contentView.setSelection(mentionView.getCursorPos());
  }

  private boolean needShowMentionView() {
    CharSequence content = contentView.getText();

    if (content.length() == 1 && isTypedAtSign()) {
      return true;
    }

    if (!hasEmptySpaceBeforeCursor() && isTypedAtSign()) {
      return false;
    }

    if (isDeleteLastCharOfMentionTag() || isCursorAfterUserTag()) {
      return false;
    }

    if (hasEmptySpaceBeforeCursor() && isTypedAtSign()) {
      return true;
    }

    if (hasUserWithPrefixOfAtSignToCursor()) {
      return true;
    }

    return false;
  }

  private boolean isTypedAtSign() {
    if (getCursorPos() < 1) {
      return false;
    }

    return contentView.getText().charAt(getCursorPos() - 1) == '@';
  }

  private boolean hasEmptySpaceBeforeCursor() {
    CharSequence content = contentView.getText();

    if (getCursorPos() < 2) {
      return content.toString().equals(" ");
    }

    return content.subSequence(getCursorPos() - 2, getCursorPos() - 1).toString().equals(" ");
  }

  private boolean hasUserWithPrefixOfAtSignToCursor() {
    CharSequence startToCursor = contentView.getText().subSequence(0, getCursorPos());
    int lastIndexOfAtSign = startToCursor.toString().lastIndexOf('@');

    if (lastIndexOfAtSign == -1) {
      return false;
    }

    String atSignToCursor = startToCursor.subSequence(lastIndexOfAtSign + 1, getCursorPos()).toString();

    return mentionView.hasUserWithPrefix(atSignToCursor);
  }

  private boolean isCursorAfterUserTag() {
    return stream(mentions)
      .anyMatch(mentionUser -> this.getCursorPos() - 1 == mentionUser.range.to);
  }

  private boolean isDeleteLastCharOfMentionTag() {
    return stream(mentions)
      .anyMatch(mentionUser -> this.getCursorPos() == mentionUser.range.to);
  }

  private Mention getMentionTagBeforeCursor() {
    return stream(mentions)
      .filter(mentionUser -> this.getCursorPos() == mentionUser.range.to)
      .findFirst().get();
  }

  private String getTextBetweenAtSignAndCursor() {
    CharSequence startToCursor = contentView.getText().subSequence(0, getCursorPos());
    int lastIndexOfAtSign = startToCursor.toString().lastIndexOf('@');
    return startToCursor.subSequence(lastIndexOfAtSign + 1, getCursorPos()).toString();
  }

  private boolean isCursorInMiddleOfMentionTag() {
    return stream(mentions)
      .anyMatch(mentionUser ->
        mentionUser.range.from < this.getCursorPos() &&
          this.getCursorPos() < mentionUser.range.to);
  }

  private Mention getMentionTagAtCursorPos() {
    return stream(mentions)
      .filter(mentionUser -> mentionUser.range.from < this.getCursorPos() &&
        this.getCursorPos() < mentionUser.range.to)
      .findFirst().get();
  }

  private void showContentView() {
    mentionView.setVisibility(View.GONE);
    contentPanel.setVisibility(View.VISIBLE);
    contentView.requestFocus();
  }

  private void showMentionView() {
    mentionView.setVisibility(View.VISIBLE);
    contentPanel.setVisibility(View.GONE);
  }

  private void addMentionTagToContent(User user) {
    addMentionTag(user);
    updateMentionTagPos();
    updateContent();
    moveCursorToLastText();
  }

  private void addMentionTag(User user) {
    Range range = Range.create(getCursorPos(), getCursorPos() + user.name.length());
    Mention tag = new Mention(range, user);
    mentions.add(tag);
  }

  private void removeMentionTag(Mention tag) {
    mentionView.removeUser(tag.user);
    mentions.remove(tag);
    int cursorPos = getCursorPos();
    updateContent();
    contentView.setSelection(cursorPos);
  }

  private void removeMentionTagFromContent(Mention mention) {
    removeMentionTag(mention);
    contentView.getText().delete(mention.range.from, mention.range.to);
    updateMentionTagPos();
    updateContent();
    moveCursorToLastText();
  }

  private void updateContent() {
    CharSequence content = contentView.getText().toString();

    List<Range> tagRanges = StreamSupport.stream(mentions)
      .map(tag -> tag.range)
      .map(range -> Range.create(range.from, range.to + 1))
      .collect(Collectors.toList());

    int textColor = tagRanges.size() <= 0 ? R.color.c2 : R.color.c9;

    NRichText newContent = NRichText.create(contentView.getContext(), content)
      .ranges(tagRanges)
      .bold()
      .textColor(textColor);

    removeTextChangeListenerForMention();
    contentView.setText(newContent);
    addTextChangeListenerForMention();
  }

  private int getCursorPos() {
    return contentView.getSelectionStart();
  }

  private void moveCursorToLastText() {
    contentView.setSelection(contentView.getText().length());
  }

  private void addTextChangeListenerForMention() {
    contentView.removeTextChangedListener(textChangedListenerForMention);
    contentView.addTextChangedListener(textChangedListenerForMention);
  }

  private void removeTextChangeListenerForMention() {
    contentView.removeTextChangedListener(textChangedListenerForMention);
  }

  public static class Mention implements Serializable {
    Range range;
    User user;
    boolean posUpdated;

    Mention(Range range, User user) {
      this.range = range;
      this.user = user;
    }
  }

}
