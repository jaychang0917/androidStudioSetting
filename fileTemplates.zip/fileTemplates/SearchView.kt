package ${PACKAGE_NAME}

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import com.tinda.app.R
import kotlinx.android.synthetic.main.view_search.view.*

class ${NAME} : LinearLayout {
  var searchCallback: ((String) -> Unit)? = null
  var clearCallback: (() -> Unit)? = null

  constructor(ctx: Context) : this(ctx, null, 0)
  constructor(ctx: Context, attrs: AttributeSet?) : this(ctx, attrs, 0)
  constructor(ctx: Context, attrs: AttributeSet?, defaultStyle: Int) : super(ctx, attrs, defaultStyle) {
    LayoutInflater.from(context).inflate(R.layout.view_search, this)
    config()
  }

  private fun config() {
    searchEditText.addTextChangedListener(object : TextWatcher {
      override fun afterTextChanged(s: Editable) = Unit

      override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) = Unit

      override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
        closeButton.visibility = if (searchEditText.text.isNullOrBlank()) { View.INVISIBLE } else { View.VISIBLE }
      }
    })
    searchEditText.setOnEditorActionListener { _, actionId, _ ->
      if (actionId == EditorInfo.IME_ACTION_SEARCH) {
        searchCallback?.invoke(searchEditText.text.toString())
        true
      } else {
        false
      }
    }

    closeButton.setOnClickListener {
      clear()
    }
  }

  private fun clear() {
    searchEditText.setText("")
    closeButton.visibility = View.INVISIBLE
    clearCallback?.invoke()
  }
}