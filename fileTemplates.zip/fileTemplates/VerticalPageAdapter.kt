package ${PACKAGE_NAME}

import android.content.Context
import android.support.v4.view.PagerAdapter
import android.view.View
import android.view.ViewGroup

class VerticalPageAdapter(val context: Context, private val viewList: List<View>) : PagerAdapter() {
  override fun instantiateItem(collection: ViewGroup, position: Int): Any {
    val view = viewList[position]
    collection.addView(view)
    return view
  }

  override fun destroyItem(collection: ViewGroup, position: Int, view: Any) {
    collection.removeView(view as View)
  }

  override fun getCount(): Int {
    return viewList.size
  }

  override fun isViewFromObject(view: View, obj: Any): Boolean {
    return view === obj
  }

  override fun getItemPosition(obj: Any?): Int {
    return POSITION_NONE
  }
}
