package ${PACKAGE_NAME}

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast

import com.bumptech.glide.Glide
import com.google.android.youtube.player.YouTubeInitializationResult
import com.google.android.youtube.player.YouTubePlayer
import com.google.android.youtube.player.YouTubePlayerFragment

class ${NAME} : BaseActivity() {
  
  companion object {
    val YOUTUBE_API_KEY = ""
    val EXTRA_YOUTUBE_URL = "EXTRA_YOUTUBE_URL"
    val RECOVERY_DIALOG_REQUEST = 1000
  }

  lateinit var player: YouTubePlayer

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    setContentView(R.layout.activity_play_youtube_video)
    setStatusBarColor(android.R.color.black)
    initYoutubePlayer()
  }

  fun initYoutubePlayer() {
    val url = intent.getStringExtra(EXTRA_YOUTUBE_URL)
    val id = StringUtils.getYoutubeId(url)
    val thumbnail = StringUtils.getYoutubeThumnbailByUrl(url)
    
    Glide.with(this).load(thumbnail).into(youtubeCoverView)

    val youTubePlayerFragment = fragmentManager.findFragmentById(R.id.youtube_fragment) as YouTubePlayerFragment

    youTubePlayerFragment.initialize(YOUTUBE_API_KEY, object : YouTubePlayer.OnInitializedListener {
      override fun onInitializationSuccess(provider: YouTubePlayer.Provider, player: YouTubePlayer, wasRestored: Boolean) {
        this@PlayYoutubeVideoActivity.player = player
        this@PlayYoutubeVideoActivity.player.setPlayerStateChangeListener(object : YouTubePlayer.PlayerStateChangeListener {
          override fun onLoading() {}

          override fun onLoaded(s: String) {}

          override fun onAdStarted() {}

          override fun onVideoStarted() {
            showPlayer()
          }

          override fun onVideoEnded() {}

          override fun onError(errorReason: YouTubePlayer.ErrorReason) {}
        })
        this@PlayYoutubeVideoActivity.player.setPlaybackEventListener(object : YouTubePlayer.PlaybackEventListener {
          override fun onPlaying() {
            showPlayer()
          }

          override fun onPaused() {
            hidePlayer()
          }

          override fun onStopped() {}

          override fun onBuffering(b: Boolean) {}

          override fun onSeekTo(i: Int) {}
        })

        if (!wasRestored) {
          player.cueVideo(id)
        }
      }

      override fun onInitializationFailure(provider: YouTubePlayer.Provider, errorReason: YouTubeInitializationResult) {
        if (errorReason.isUserRecoverableError) {
          errorReason.getErrorDialog(this@PlayYoutubeVideoActivity, RECOVERY_DIALOG_REQUEST).show()
        }
      }
    })
  }

  fun play(view: View) {
    if (!player.isPlaying) {
      player.play()
    }
  }

  fun showPlayer() {
    youtubeCoverView.visibility = View.GONE
    playButton.visibility = View.GONE
    player.setPlayerStyle(YouTubePlayer.PlayerStyle.DEFAULT)
    playerLayout.visibility = View.VISIBLE
  }

  fun hidePlayer() {
    youtubeCoverView.visibility = View.GONE
    playerLayout.visibility = View.VISIBLE
    player.setPlayerStyle(YouTubePlayer.PlayerStyle.CHROMELESS)
    playButton.visibility = View.VISIBLE
  }

}
