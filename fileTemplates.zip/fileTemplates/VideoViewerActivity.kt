package ${PACKAGE_NAME}

class ${NAME} : BaseActivity() {
  companion object {
    const val EXTRA_URL = "EXTRA_URL"
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_video_viewer)
    val url = intent.getStringExtra(EXTRA_URL)
    videoView.setVideoPath(url)
    val mediaController = MediaController(this)
    mediaController.setAnchorView(videoView)
    videoView.setMediaController(mediaController)
    videoView.setOnPreparedListener {
      videoView.start()
    }
  }
}