package ${PACKAGE_NAME}

import com.jaychang.android.extensions.core.Preference

object AppPreference: Preference(App.context) {

  var accessToken: String by PreferenceDelegate()

}