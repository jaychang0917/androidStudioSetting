package ${PACKAGE_NAME};

public class ${NAME}Repository {

  private static final ${NAME}Repository INSTANCE = new ${NAME}Repository();
  private static Api api;

  public static ${NAME}Repository getInstance() {
    return INSTANCE;
  }
  
  private ${NAME}Repository() {
    api = WebServiceManager.getRetrofit().create(Api.class);
  }

  /**
   * Api spec
   */
  private interface Api {
    
  }
}
