package ${PACKAGE_NAME};

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.jaychang.toolbox.util.SimpleTextChangedListener;

public class SearchView extends RelativeLayout {

  @BindView(R.id.editTextView)
  EditText editTextView;
  @BindView(R.id.clearView)
  ImageView clearView;

  private String hint;
  private OnClearViewClickListener onClearViewClickListener;

  public ${NAME}(Context context) {
    this(context, null);
  }

  public ${NAME}(Context context, AttributeSet attrs) {
    this(context, attrs, 0);
  }

  public ${NAME}(Context context, AttributeSet attrs, int defStyle) {
    super(context, attrs, defStyle);
    LayoutInflater.from(context).inflate(R.layout.view_search_view, this);
    ButterKnife.bind(this);

    TypedArray typedArray = context.getTheme().obtainStyledAttributes(attrs, R.styleable.${NAME}, defStyle, 0);
    hint = typedArray.getString(R.styleable.${NAME}_search_hint);
    typedArray.recycle();

    init();
  }

  private void init() {
    if (!TextUtils.isEmpty(hint)) {
      setHint(hint);
    }
    editTextView.addTextChangedListener(new SimpleTextChangedListener() {
      @Override
      public void onTextChanged(CharSequence s, int start, int before, int count) {
        if (count <= 0) {
          clearView.setVisibility(GONE);
        } else {
          clearView.setVisibility(VISIBLE);
        }
      }
    });
  }

  @OnClick(R.id.clearView)
  void clearContent() {
    editTextView.setText("");
    if (onClearViewClickListener != null) {
      onClearViewClickListener.onCleared();
    }
  }

  public void setHint(String hint) {
    editTextView.setHint(hint);
  }

  public String getContent() {
    return editTextView.getText().toString();
  }

  public EditText getEditTextView() {
    return editTextView;
  }

  public void setOnClearViewClickListener(OnClearViewClickListener onClearViewClickListener) {
    this.onClearViewClickListener = onClearViewClickListener;
  }

  public void setOnQueryChangeListener(TextWatcher textWatcher) {
    editTextView.addTextChangedListener(textWatcher);
  }

  public interface OnClearViewClickListener {
    void onCleared();
  }

}
