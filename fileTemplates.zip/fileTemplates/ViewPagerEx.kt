package ${PACKAGE_NAME}

// fix crash in PhotoView
class ${NAME} : ViewPager {
  constructor(context: Context) : super(context)
  constructor(context: Context, attrs: AttributeSet) : super(context, attrs)

  var isDraggable = true

  override fun onTouchEvent(ev: MotionEvent): Boolean {
    if (!isDraggable) {
      return false
    }

    try {
      return super.onTouchEvent(ev)
    } catch (ex: IllegalArgumentException) {
      ex.printStackTrace()
    }

    return false
  }

  override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
    if (!isDraggable) {
      return false
    }

    try {
      return super.onInterceptTouchEvent(ev)
    } catch (ex: IllegalArgumentException) {
      ex.printStackTrace()
    }

    return false
  }
}