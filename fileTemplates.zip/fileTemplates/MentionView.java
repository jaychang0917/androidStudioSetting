package ${PACKAGE_NAME};

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.jaychang.nrv.HorizontalDividerItemDecoration;
import com.jaychang.nrv.NRecyclerView;
import com.jaychang.toolbox.util.AppUtils;
import com.jaychang.toolbox.util.SimpleTextChangedListener;
import com.rsl.butterfly.R;
import com.rsl.butterfly.data.DataManager;
import com.rsl.butterfly.data.model.User;
import com.rsl.butterfly.features.topic.cell.MentionUserCell;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import java8.util.stream.Collectors;
import java8.util.stream.StreamSupport;
import rx.Subscription;

public class ${NAME} extends LinearLayout {

  @BindView(R.id.editText)
  EditText editText;
  @BindView(R.id.mentionRecyclerView)
  NRecyclerView mentionRecyclerView;

  private Subscription subscription;
  private List<User> allFriends;
  private SimpleTextChangedListener textChangedListener;
  private Callback callback;
  private List<User> mentionedUsers = new ArrayList<>();
  private String queryPrefix = "";
  private boolean isInited;

  public ${NAME}(Context context) {
    this(context, null);
  }

  public ${NAME}(Context context, AttributeSet attrs) {
    this(context, attrs, 0);
  }

  public ${NAME}(Context context, AttributeSet attrs, int defStyle) {
    super(context, attrs, defStyle);
    LayoutInflater.from(getContext()).inflate(R.layout.view_mention, this);
    ButterKnife.bind(this);
  }

  public void init() {
    textChangedListener = new SimpleTextChangedListener() {
      @Override
      public void onTextChanged(CharSequence input, int start, int before, int count) {
        if (input.length() == 0) {
          return;
        }

        if (isAtSignDeleted()) {
          callback.onCancel(${NAME}.this);
          return;
        }

        searchFriends(makeQuery());
      }
    };

    editText.addTextChangedListener(textChangedListener);
    editText.setOnClickListener(view -> callback.onCancel(${NAME}.this));

    mentionRecyclerView.useVerticalLinearMode();
    mentionRecyclerView.addItemDecoration(HorizontalDividerItemDecoration.newBuilder(getContext()).colorResId(R.color.c5).margin(AppUtils.dp2px(8)).build());

    loadAllFriends();
  }

  private void loadAllFriends() {
    if (subscription != null && !subscription.isUnsubscribed()) {
      subscription.unsubscribe();
    }

    subscription = DataManager.getInstance().getFriends()
      .subscribe(
        allFriends -> {
          this.allFriends = allFriends;
          bindFriends(allFriends);
          isInited = true;
        }
      );
  }

  private void bindFriends(List<User> friends) {
    if (friends.size() <= 0 && isInited) {
      callback.onCancel(${NAME}.this);
      return;
    }

    mentionRecyclerView.removeAllCells();

    for (User friend : friends) {
      if (mentionedUsers.contains(friend)) {
        continue;
      }
      MentionUserCell cell = new MentionUserCell(friend);
      cell.setCallback(user -> {
        updateContent(user.name);
        mentionedUsers.add(user);
        callback.onUserSelected(${NAME}.this, user);
      });
      mentionRecyclerView.addCell(cell);
    }

    mentionRecyclerView.getAdapter().notifyDataSetChanged();
  }

  private void searchFriends(String name) {
    if (allFriends == null || allFriends.size() <= 0) {
      return;
    }

    List<User> friends = StreamSupport.stream(allFriends)
      .filter(user -> user.name.startsWith(name))
      .collect(Collectors.toList());

    bindFriends(friends);
  }

  private boolean isAtSignDeleted() {
    return getLastIndexOfAtSign() == -1;
  }

  private int getLastIndexOfAtSign() {
    CharSequence startToCursor = editText.getText().subSequence(0, getCursorPos());
    return startToCursor.toString().lastIndexOf('@');
  }

  private String makeQuery() {
    return editText.getText().subSequence(getLastIndexOfAtSign() + 1, getCursorPos()).toString();
  }

  private void updateContent(String username) {
    editText.removeTextChangedListener(textChangedListener);

    int index = getLastIndexOfAtSign() + 1;
    editText.getText().delete(index, getCursorPos());
    editText.getText().insert(index, username + " ");

    editText.addTextChangedListener(textChangedListener);
  }

  public void release() {
    if (subscription != null && !subscription.isUnsubscribed()) {
      subscription.unsubscribe();
    }
    editText.removeTextChangedListener(textChangedListener);
    editText.getText().clear();
    textChangedListener = null;
    mentionedUsers.clear();
    queryPrefix = "";
  }

  public void setCallback(Callback callback) {
    this.callback = callback;
  }

  public void setContent(CharSequence text) {
    editText.removeTextChangedListener(textChangedListener);
    editText.setText(text);
    editText.setSelection(text.length());
    editText.addTextChangedListener(textChangedListener);
  }

  public CharSequence getContent() {
    return editText.getText();
  }

  public void setCursorPos(int cursorPos) {
    editText.setSelection(cursorPos);
  }

  public int getCursorPos() {
    return editText.getSelectionStart();
  }

  public void setQueryPrefix(String queryPrefix) {
    this.queryPrefix = queryPrefix;
  }

  public void removeUser(User user) {
    mentionedUsers.remove(user);
  }

  public boolean hasUserWithPrefix(String prefix) {
    return StreamSupport.stream(allFriends)
      .anyMatch(user -> user.name.startsWith(prefix));
  }

  @Override
  public void setVisibility(int visibility) {
    super.setVisibility(visibility);
    searchFriends(queryPrefix);
  }

  public interface Callback {
    void onCancel(${NAME} view);
    void onUserSelected(${NAME} view, User friend);
  }

}
