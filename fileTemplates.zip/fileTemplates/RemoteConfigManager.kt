package ${PACKAGE_NAME}

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings

object RemoteConfigManager {
  private var TAG = RemoteConfigManager.javaClass.name

  private val KEY_MIN_VERSION = "android_min_version"

  @SuppressLint("StaticFieldLeak")
  private var remoteConfig = FirebaseRemoteConfig.getInstance().apply {
    val settings = FirebaseRemoteConfigSettings.Builder().setDeveloperModeEnabled(BuildConfig.DEBUG).build()
    setConfigSettings(settings)
    setDefaults(mapOf(
      KEY_MIN_VERSION to "1"
    ))
  }

  fun fetch() {
    val cacheExpiration = if (remoteConfig.info.configSettings.isDeveloperModeEnabled) 0L else 43200L // default 12 hours
    remoteConfig.fetch(cacheExpiration)
      .addOnCompleteListener { task ->
        if (task.isSuccessful) {
          remoteConfig.activateFetched()
          Log.d(TAG, "Remote Config fetched.")
        } else {
          Log.d(TAG, "Fail to fetch Remote Config.")
        }
      }
  }

  fun isNeedUpdate(context: Context): Boolean {
    return context.versionCode < remoteConfig.getLong(KEY_MIN_VERSION)
  }
}