package ${PACKAGE_NAME}

import android.graphics.Color
import android.os.Bundle
import com.buddigo.buying.app.R
import com.buddigo.buying.app.data.Events
import com.jaychang.extensions.util.statusBarColor
import kotlinx.android.synthetic.main.activity_gallery_show_viewer.*
import org.greenrobot.eventbus.EventBus

class ${NAME}: BaseActivity() {
  companion object {
    const val EXTRA_URLS = "EXTRA_URLS"
    const val EXTRA_POS = "EXTRA_POS"
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_gallery_show_viewer)

    statusBarColor = Color.BLACK
    closeView.setOnClickListener { finish() }
    galleryShowView.isViewMode = true
    galleryShowView.setData(intent.getStringArrayListExtra(EXTRA_URLS), currentPos = intent.getIntExtra(EXTRA_POS, 0))
  }

  override fun onDestroy() {
    super.onDestroy()
    EventBus.getDefault().post(Events.GalleryPosUpdated(galleryShowView.currentPos))
  }
}