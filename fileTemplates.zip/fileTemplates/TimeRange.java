package ${PACKAGE_NAME};

import org.threeten.bp.LocalTime;

public class TimeRange {

  private LocalTime start;
  private LocalTime end;

  private TimeRange(LocalTime start, LocalTime end) {
    this.start = start;
    this.end = end;
  }

  public static TimeRange of(LocalTime start, LocalTime end) {
    return new TimeRange(start, end);
  }

  public static boolean isBetween(LocalTime time, ${NAME} range) {
    return (time.equals(range.start) || time.isAfter(range.start)) &&
      (time.equals(range.end) || time.isBefore(range.end));
  }

}