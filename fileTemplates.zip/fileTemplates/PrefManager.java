package ${PACKAGE_NAME};

import android.content.Context;

import com.caminotoys.transformer.R;
import com.jaychang.utils.PreferenceUtils;

public class ${NAME} {

  private static final String ENABLE_NOTIFICATION = "ENABLE_NOTIFICATION";
  private static final String LANGUAGE = "LANGUAGE";

  public static void setEnableNotification(Context context, boolean val) {
    PreferenceUtils.saveBoolean(context, ENABLE_NOTIFICATION, val);
  }

  public static boolean isNotificationEnabled(Context context) {
    return PreferenceUtils.getBoolean(context, ENABLE_NOTIFICATION);
  }

  public static void setEngLanguage(Context context) {
    PreferenceUtils.saveString(context, LANGUAGE, "eng");
  }

  public static void setTcLanguage(Context context) {
    PreferenceUtils.saveString(context, LANGUAGE, "tc");
  }

  public static void setScLanguage(Context context) {
    PreferenceUtils.saveString(context, LANGUAGE, "sc");
  }

  public static boolean isUsingEngLanguage(Context context) {
    return "eng".equals(PreferenceUtils.getString(context, LANGUAGE));
  }

  public static boolean isUsingTcLanguage(Context context) {
    return "tc".equals(PreferenceUtils.getString(context, LANGUAGE));
  }

  public static boolean isUsingScLanguage(Context context) {
    return "sc".equals(PreferenceUtils.getString(context, LANGUAGE));
  }

  public static int getLanguage(Context context) {
    if (isUsingEngLanguage(context)) {
      return R.string.settings_lang_eng;
    } else if (isUsingTcLanguage(context)) {
      return R.string.settings_lang_tc;
    } else if (isUsingScLanguage(context)) {
      return R.string.settings_lang_sc;
    }

    return -1;
  }

}
