package ${PACKAGE_NAME};

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.rsl.butterfly.R;

public class ${NAME} {

  private TextView messageView;
  private TextView leftBottomView;
  private TextView rightBottomView;

  private MaterialDialog dialog;
  private int message = -1;
  private int leftButtonText = -1;
  private int rightButtonText = -1;
  private View.OnClickListener onRightButtonClickListener;
  private View.OnClickListener onLeftButtonClickListener;

  private ${NAME}(Context context) {
    this.dialog = new MaterialDialog.Builder(context)
      .customView(R.layout.dialog_message, false)
      .build();

    LinearLayout rootView = (LinearLayout) dialog.getCustomView();
    messageView = (TextView) rootView.findViewById(R.id.messageView);
    leftBottomView = (TextView) rootView.findViewById(R.id.leftBottomView);
    rightBottomView = (TextView) rootView.findViewById(R.id.rightBottomView);
  }

  public static ${NAME} create(Context context) {
    return new ${NAME}(context);
  }

  public ${NAME} message(int message) {
    this.message = message;
    return this;
  }

  public ${NAME} leftButtonText(int leftButtonText) {
    this.leftButtonText = leftButtonText;
    return this;
  }

  public ${NAME} rightButtonText(int rightButtonText) {
    this.rightButtonText = rightButtonText;
    return this;
  }

  public ${NAME} onRightButtonClickListener(View.OnClickListener onRightButtonClickListener) {
    this.onRightButtonClickListener = onRightButtonClickListener;
    return this;
  }

  public ${NAME} onLeftButtonClickListener(View.OnClickListener onLeftButtonClickListener) {
    this.onLeftButtonClickListener = onLeftButtonClickListener;
    return this;
  }

  public MaterialDialog build() {
    if (message != -1) {
      messageView.setText(message);
    }

    if (leftButtonText != -1) {
      leftBottomView.setText(leftButtonText);
    }

    if (rightButtonText != -1) {
      rightBottomView.setText(rightButtonText);
    }

    leftBottomView.setOnClickListener(view -> {
      dialog.dismiss();
      if (onLeftButtonClickListener != null) {
        onLeftButtonClickListener.onClick(view);
      }
    });

    rightBottomView.setOnClickListener(view -> {
      dialog.dismiss();
      if (onRightButtonClickListener != null) {
        onRightButtonClickListener.onClick(view);
      }
    });

    return dialog;
  }

}