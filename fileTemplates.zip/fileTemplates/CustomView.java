package ${PACKAGE_NAME};

import android.content.Context;
import android.content.res.TypedArray;
import android.support.annotation.StringRes;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.caminotoys.transformer.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ${NAME} extends LinearLayout {

  @BindView(R.id.titleView)
  TextView titleView;
  @BindView(R.id.navIconView)
  ImageView navIconView;

  private int title;
  private int icon;
  private boolean showNavIcon;

  public ${NAME}(Context context) {
    this(context, null);
  }

  public ${NAME}(Context context, AttributeSet attrs) {
    this(context, attrs, 0);
  }

  public ${NAME}(Context context, AttributeSet attrs, int defStyle) {
    super(context, attrs, defStyle);
    LayoutInflater.from(context).inflate(R.layout.view_link, this);
    ButterKnife.bind(this);

    TypedArray typedArray = context.getTheme().obtainStyledAttributes(attrs, R.styleable.${NAME}, defStyle, 0);
    this.title = typedArray.getResourceId(R.styleable.${NAME}_link_title, 0);
    this.icon = typedArray.getResourceId(R.styleable.${NAME}_link_icon, 0);
    this.showNavIcon = typedArray.getBoolean(R.styleable.${NAME}_link_showNavIcon, false);
    typedArray.recycle();

    init();
  }

  private void init() {
    setTitle(title);
    setIcon(icon);
    setShowNavIcon(showNavIcon);
  }

  public int getTitle() {
    return title;
  }

  public void setTitle(@StringRes int title) {
    this.title = title;
    titleView.setText(title);
  }

  public int getIcon() {
    return icon;
  }

  public void setIcon(int icon) {
    this.icon = icon;
    titleView.setCompoundDrawablesWithIntrinsicBounds(icon, 0, 0, 0);
  }

  public boolean isShowNavIcon() {
    return showNavIcon;
  }

  public void setShowNavIcon(boolean showNavIcon) {
    this.showNavIcon = showNavIcon;
    if (showNavIcon) {
      navIconView.setVisibility(VISIBLE);
    } else {
      navIconView.setVisibility(GONE);
    }
  }

}
