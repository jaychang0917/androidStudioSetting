package ${PACKAGE_NAME};

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.rsl.butterfly.R;
import com.rsl.butterfly.data.model.Hashtag;
import com.tokenautocomplete.TokenCompleteTextView;

public class ${NAME} extends TokenCompleteTextView<Hashtag> {

  public ${NAME}(Context context, AttributeSet attrs) {
    super(context, attrs);
  }

  @Override
  protected View getViewForObject(Hashtag hashtag) {
    TextView view = (TextView) LayoutInflater.from(getContext()).inflate(R.layout.view_hashtag_with_bg, (ViewGroup) getParent(), false);
    if (!hashtag.name.startsWith("#")) {
      view.setText("#" + hashtag.name);
    } else {
      view.setText(hashtag.name);
    }
    return view;
  }

  @Override
  protected Hashtag defaultObject(String completionText) {
    return new Hashtag(completionText);
  }
}
