package ${PACKAGE_NAME}

import android.app.DialogFragment
import android.app.FragmentManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

class CustomDialogFragment: DialogFragment() {
  override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
     return inflater.inflate(R.layout.custom_dialog, container, false)
  }

  override fun onResume() {
    super.onResume()
    val density = resources.displayMetrics.density.toInt()
    dialog.window.setLayout(200 * density, 200 * density)
    dialog.setCanceledOnTouchOutside(false)
  }

  fun show(fragmentManager: FragmentManager) {
    show(fragmentManager, javaClass.name)
  }
}