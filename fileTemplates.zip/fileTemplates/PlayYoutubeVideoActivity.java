package ${PACKAGE_NAME};

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerFragment;
import com.jaychang.toolbox.util.AppUtils;
import com.jaychang.toolbox.widget.NToolbar;
import com.rsl.butterfly.R;
import com.rsl.butterfly.app.BaseActivity;
import com.rsl.butterfly.constant.Key;
import com.rsl.butterfly.data.model.YoutubeVideo;
import com.rsl.butterfly.widget.AspectRatioImageView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ${NAME} extends BaseActivity {

  @BindView(R.id.toolbar)
  NToolbar toolbar;
  @BindView(R.id.youtubeCoverView)
  AspectRatioImageView youtubeCoverView;
  @BindView(R.id.playButton)
  ImageView playButton;
  @BindView(R.id.youtubeCoverLayout)
  FrameLayout youtubeCoverLayout;
  @BindView(R.id.playerLayout)
  FrameLayout playerLayout;

  public static final String EXTRA_YOUTUBE_VIDEO = "EXTRA_YOUTUBE_VIDEO";
  public static final String EXTRA_TOPIC_TITLE = "EXTRA_TOPIC_TITLE";
  private static final int RECOVERY_DIALOG_REQUEST = 1000;
  private YouTubePlayer player;

  @Override
  protected void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    setContentView(R.layout.activity_play_youtube_video);
    AppUtils.setStatusBarColor(this, android.R.color.black);
    ButterKnife.bind(this);
    init();
  }

  private void init() {
    initToolbar();
    initYoutubePlayer();
  }

  private void initToolbar() {
    String topicTitle = getIntent().getStringExtra(EXTRA_TOPIC_TITLE);
    if (!TextUtils.isEmpty(topicTitle)) {
      toolbar.setTitle(topicTitle);
    }
  }

  private void initYoutubePlayer() {
    YoutubeVideo youtubeVideo = (YoutubeVideo) getIntent().getSerializableExtra(EXTRA_YOUTUBE_VIDEO);

    Glide.with(this).load(youtubeVideo.getThumbnailUrl()).into(youtubeCoverView);

    YouTubePlayerFragment youTubePlayerFragment = (YouTubePlayerFragment) getFragmentManager().findFragmentById(R.id.youtube_fragment);

    youTubePlayerFragment.initialize(Key.YOUTUBE, new YouTubePlayer.OnInitializedListener() {
      @Override
      public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer player, boolean wasRestored) {
        ${NAME}.this.player = player;
        ${NAME}.this.player.setPlayerStateChangeListener(new YouTubePlayer.PlayerStateChangeListener() {
          @Override
          public void onLoading() {

          }

          @Override
          public void onLoaded(String s) {

          }

          @Override
          public void onAdStarted() {

          }

          @Override
          public void onVideoStarted() {
            showPlayer();
          }

          @Override
          public void onVideoEnded() {

          }

          @Override
          public void onError(YouTubePlayer.ErrorReason errorReason) {

          }
        });
        ${NAME}.this.player.setPlaybackEventListener(new YouTubePlayer.PlaybackEventListener() {
          @Override
          public void onPlaying() {
            showPlayer();
          }

          @Override
          public void onPaused() {
            hidePlayer();
          }

          @Override
          public void onStopped() {

          }

          @Override
          public void onBuffering(boolean b) {

          }

          @Override
          public void onSeekTo(int i) {

          }
        });

        if (!wasRestored) {
          player.cueVideo(youtubeVideo.getId());
        }
      }

      @Override
      public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult errorReason) {
        if (errorReason.isUserRecoverableError()) {
          errorReason.getErrorDialog(${NAME}.this, RECOVERY_DIALOG_REQUEST).show();
        } else {
          String errorMessage = getString(R.string.TXT_MSG_General_Error);
          Toast.makeText(${NAME}.this, errorMessage, Toast.LENGTH_LONG).show();
        }
      }
    });
  }

  @OnClick({R.id.youtubeCoverLayout, R.id.playButton})
  void play() {
    if (player != null && !player.isPlaying()) {
      player.play();
    }
  }



  @OnClick(R.id.left_icon)
  void back() {
    finish();
  }

  private void showPlayer() {
    youtubeCoverView.setVisibility(View.GONE);
    playButton.setVisibility(View.GONE);
    player.setPlayerStyle(YouTubePlayer.PlayerStyle.DEFAULT);
    playerLayout.setVisibility(View.VISIBLE);
  }

  private void hidePlayer() {
    youtubeCoverView.setVisibility(View.GONE);
    playerLayout.setVisibility(View.VISIBLE);
    player.setPlayerStyle(YouTubePlayer.PlayerStyle.CHROMELESS);
    playButton.setVisibility(View.VISIBLE);
  }

}
