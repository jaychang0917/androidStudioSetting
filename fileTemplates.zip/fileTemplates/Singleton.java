#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
public class ${NAME}{
    private static final ${NAME} INSTANCE = new ${NAME}();

    public static ${NAME} getInstance() {
        return INSTANCE;
    }

    private ${NAME}() {
    }
}
