package ${PACKAGE_NAME}

import android.content.Context
import android.support.design.widget.BottomSheetBehavior
import android.support.design.widget.BottomSheetDialog
import android.view.LayoutInflater
import android.view.View

open class ${NAME} : BottomSheetDialog {
  protected var behavior: BottomSheetBehavior<View>

  constructor(context: Context, @LayoutRes layout: Int) : super(context) {
    val contentView = LayoutInflater.from(context).inflate(layout, null)
    setContentView(contentView)
    behavior = BottomSheetBehavior.from(contentView.parent as View)
  }

  fun expand() {
    behavior.state = BottomSheetBehavior.STATE_EXPANDED
  }

  fun collapse() {
    behavior.state = BottomSheetBehavior.STATE_COLLAPSED
  }

  fun toggle() {
    if (behavior.state == BottomSheetBehavior.STATE_EXPANDED) {
      collapse()
    } else {
      expand()
    }
  }

  fun setIsHideable(value: Boolean) {
    behavior.isHideable = value
  }

  fun setPeekHeight(value: Int) {
    behavior.peekHeight = value
  }
}}