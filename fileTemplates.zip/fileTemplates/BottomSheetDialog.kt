package ${PACKAGE_NAME}

import android.content.Context
import android.support.design.widget.BottomSheetBehavior
import android.support.design.widget.BottomSheetDialog
import android.view.LayoutInflater
import android.view.View

open class BottomInfoDialog : BottomSheetDialog {
  private var behavior: BottomSheetBehavior<View>
  var onSlide: ((offset: Float) -> Unit)? = null
  var onStateChanged: ((newState: Int) -> Unit)? = null

  constructor(context: Context, @LayoutRes layout: Int) : super(context) {
    val contentView = LayoutInflater.from(context).inflate(layout, null, false)
    setContentView(contentView)

    (contentView.parent as View).setBackgroundColor(Color.TRANSPARENT)

    behavior = BottomSheetBehavior.from(contentView.parent as View)
    behavior.setBottomSheetCallback(object: BottomSheetBehavior.BottomSheetCallback() {
      override fun onSlide(bottomSheet: View, slideOffset: Float) {
        onSlide?.invoke(slideOffset)
      }

      override fun onStateChanged(bottomSheet: View, newState: Int) {
        onStateChanged?.invoke(newState)
        if (newState == BottomSheetBehavior.STATE_HIDDEN) {
          super@BottomInfoDialog.dismiss()
        }
      }
    })
  }

  override fun dismiss() {
    behavior.state = BottomSheetBehavior.STATE_HIDDEN
  }

  fun toggle() {
    if (behavior.state == BottomSheetBehavior.STATE_EXPANDED) {
      dismiss()
    } else {
      show()
    }
  }

  fun isExpanded(): Boolean {
    return behavior.state == BottomSheetBehavior.STATE_EXPANDED
  }

  fun setIsHideable(value: Boolean) {
    behavior.isHideable = value
  }

  fun setPeekHeight(value: Int) {
    behavior.peekHeight = value
  }
}