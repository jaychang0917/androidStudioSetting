package ${PACKAGE_NAME}

import com.google.firebase.iid.FirebaseInstanceId
import com.google.firebase.iid.FirebaseInstanceIdService

class FcmInstanceIdRefreshService : FirebaseInstanceIdService() {

  /**
   * Called at first install time or if InstanceID token is updated. This may occur if the security of
   * the previous token had been compromised. This call is initiated by the
   * InstanceID provider.
   */
  override fun onTokenRefresh() {
    val refreshedToken = FirebaseInstanceId.getInstance().token
    sendRegistrationToServer(refreshedToken)
  }

  private fun sendRegistrationToServer(refreshedToken: String?) {
    // custom implementation
  }
}
