package ${PACKAGE_NAME};

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;

import com.caminotoys.transformer.R;
import com.caminotoys.transformer.activity.base.ProjectBaseActivity;
import com.caminotoys.transformer.activity.data.PrefManager;

import java.util.Locale;

public class ${NAME} extends ProjectBaseActivity {

  @Override
  protected void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_landing);

    setAppLanguage();

    new Handler().postDelayed(new Runnable() {
      @Override
      public void run() {
        startActivity(new Intent(${NAME}.this, HomeTabActivity.class));
      }
    }, 500);
  }

  private void setAppLanguage() {
    boolean isLangSet = PrefManager.getLanguage(this) != -1;

    if (isLangSet) {
      return;
    }

    Locale curLocale = Locale.getDefault();
    if (curLocale.equals(Locale.ENGLISH)) {
      PrefManager.setEngLanguage(this);
    } else if (curLocale.equals(Locale.TRADITIONAL_CHINESE)) {
      PrefManager.setTcLanguage(this);
    } else if (curLocale.equals(Locale.SIMPLIFIED_CHINESE)) {
      PrefManager.setScLanguage(this);
    } else {
      PrefManager.setEngLanguage(this);
    }
  }

}
