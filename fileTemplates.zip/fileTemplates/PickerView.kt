import android.content.Context
import android.support.v4.content.ContextCompat
import android.util.AttributeSet
import com.bigkoo.pickerview.adapter.WheelAdapter
import com.bigkoo.pickerview.lib.WheelView
// implementation 'com.github.jaychang0917redso:Android-PickerView:0.3'
class PickerView : WheelView {

  constructor(ctx: Context) : this(ctx, null)
  constructor(ctx: Context, attrs: AttributeSet?) : super(ctx, attrs) {
    setCyclic(false)
    setDividerColor(ContextCompat.getColor(context, R.color.paleGrey))
    setTextSize(18f)
    setTextColorCenter(ContextCompat.getColor(context, R.color.marineBlue))
    setTextColorOut(ContextCompat.getColor(context, R.color.greyLightBlue))
    setLineSpacingMultiplier(4f)
    setItemsVisible(3)
  }

  fun <T> setData(data: List<T>) {
    adapter = PickerViewAdapter(data)
  }

  class PickerViewAdapter<T>(val list: List<T>) : WheelAdapter<T> {
    override fun getItemsCount(): Int {
      return list.size
    }

    override fun indexOf(time: T): Int {
      return list.indexOf(time)
    }

    override fun getItem(index: Int): T {
      return list[index]
    }
  }

}