package ${PACKAGE_NAME};

import com.facebook.stetho.okhttp3.StethoInterceptor;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

#if ($Use_Realm.equals("t"))
import io.realm.RealmObject;
import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
#end
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
#if ($Use_RxJava.equals("t"))
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
#end
import retrofit2.converter.gson.GsonConverterFactory;
#if ($Use_RxJava.equals("t"))
import rx.schedulers.Schedulers;
#end

public class ApiClient {

  private static final String BASE_URL;
  private static Retrofit retrofit;
  private static HashMap<String, String> defaultParams = new HashMap<>();
  private static HashMap<String, String> defaultHeaders = new HashMap<>();
  private static String jsonContentKey;

  static {
    BASE_URL = "$Base_Url";
    jsonContentKey = "$Json_Content_Key";
//    defaultParams.put("contentKey", "value");
//    defaultHeaders.put("contentKey", "value");
    setup();
  }

  private static void setup() {
    OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient.Builder();
    if (BuildConfig.DEBUG) {
      okHttpClientBuilder.addNetworkInterceptor(new StethoInterceptor());
    }
    if (defaultParams.keySet().size() > 0) {
      okHttpClientBuilder.addInterceptor(new Interceptor() {
        @Override
        public Response intercept(Chain chain) throws IOException {
          Request oldRequest = chain.request();
          HttpUrl.Builder urlBuilder = oldRequest.url().newBuilder();
          for (Map.Entry<String, String> params : defaultParams.entrySet()) {
            urlBuilder.addQueryParameter(params.getKey(), params.getValue());
          }
          Request newRequest = oldRequest.newBuilder().url(urlBuilder.build()).build();
          return chain.proceed(newRequest);
        }
      });
    }
    if (defaultHeaders.keySet().size() > 0) {
      okHttpClientBuilder.addInterceptor(new Interceptor() {
        @Override
        public Response intercept(Chain chain) throws IOException {
          Request request = chain.request();
          Request.Builder requestBuilder = request.newBuilder();
          for (Map.Entry<String, String> headers : defaultHeaders.entrySet()) {
            requestBuilder.addHeader(headers.getKey(), headers.getValue());
          }
          return chain.proceed(request);
        }
      });
    }

    GsonBuilder gsonBuilder = new GsonBuilder();
    gsonBuilder.setPrettyPrinting();
    if (!jsonContentKey.equals("")) {
      gsonBuilder.registerTypeAdapterFactory(CustomJsonDeserializer.create(jsonContentKey));
    }
    #if ($Use_Realm.equals("t"))
    gsonBuilder.setExclusionStrategies(new ExclusionStrategy() {
      @Override
      public boolean shouldSkipField(FieldAttributes f) {
        return f.getDeclaringClass().equals(RealmObject.class);
      }
    
      @Override
      public boolean shouldSkipClass(Class<?> clazz) {
        return false;
      }
    });
    #end
    
    Retrofit.Builder retrofitBuilder = new Retrofit.Builder();
    retrofitBuilder.baseUrl(BASE_URL).client(okHttpClientBuilder.build());
    retrofitBuilder.addConverterFactory(GsonConverterFactory.create(gsonBuilder.create()));
    #if ($Use_RxJava.equals("t"))
    retrofitBuilder.addCallAdapterFactory(RxJavaCallAdapterFactory.createWithScheduler(Schedulers.io()));
    #end

    retrofit = retrofitBuilder.build();
  }

  public static Api getApi() {
    return retrofit.create(Api.class);
  }


  private static class CustomJsonDeserializer implements TypeAdapterFactory {

    private String contentKey;

    public static CustomJsonDeserializer create(String contentKey) {
      CustomJsonDeserializer cjd = new CustomJsonDeserializer();
      cjd.contentKey = contentKey;
      return cjd;
    }

    @Override
    public <T> TypeAdapter<T> create(Gson gson, final TypeToken<T> type) {

      final TypeAdapter<T> delegate = gson.getDelegateAdapter(this, type);
      final TypeAdapter<JsonElement> elementAdapter = gson.getAdapter(JsonElement.class);

      return new TypeAdapter<T>() {
        @Override
        public void write(JsonWriter out, T value) throws IOException {
          delegate.write(out, value);
        }

        @Override
        public T read(JsonReader in) throws IOException {
          JsonElement jsonElement = elementAdapter.read(in);

          if (jsonElement.isJsonObject()) {
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            if (jsonObject.has(contentKey)) {
              jsonElement = jsonObject.get(contentKey);
            }
          }

          return delegate.fromJsonTree(jsonElement);
        }
      }.nullSafe();
    }
  }
}
