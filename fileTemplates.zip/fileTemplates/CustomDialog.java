package ${PACKAGE_NAME};

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.rsl.butterfly.R;

import java.util.List;

public class ${NAME} {

  private TextView titleView;

  private MaterialDialog dialog;
  private Context context;
  private int title = -1;
  private OnItemClickListener onItemClickListener;

  private ${NAME}(Context context) {
    this.context = context;
    this.dialog = new MaterialDialog.Builder(context)
      .customView(R.layout.dialog_, false)
      .build();

    LinearLayout rootView = (LinearLayout) dialog.getCustomView();
    titleView = (TextView) rootView.findViewById(R.id.titleView);
  }

  public static ${NAME} create(Context context) {
    return new ${NAME}(context);
  }

  public void init() {
  }

  public ${NAME} title(int title) {
    this.title = title;
    return this;
  }

  public ${NAME} onItemClickListener(OnItemClickListener onItemClickListener) {
    this.onItemClickListener = onItemClickListener;
    return this;
  }

  public MaterialDialog build() {
    if (title != -1) {
      titleView.setText(title);
    } else {
      titleView.setVisibility(View.GONE);
    }

    return dialog;
  }

  public interface OnItemClickListener {
    void onItemClicked(String key, String value);
  }

}