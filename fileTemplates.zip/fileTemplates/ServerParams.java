package ${PACKAGE_NAME};

import com.google.common.collect.Maps;
import com.jaychang.toolbox.util.AppUtils;
import com.rsl.butterfly.util.Utils;

import java.util.HashMap;

public class ServerParams {
  private static HashMap<String, String> params = new HashMap<>();

  static {
  }

  public static HashMap<String, String> getDefaultParams() {
    return Maps.newHashMap(params);
  }

}
