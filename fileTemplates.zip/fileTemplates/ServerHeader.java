package ${PACKAGE_NAME};

import com.google.common.collect.Maps;

import java.util.HashMap;

public class ServerHeader {
  
  public static HashMap<String, String> getDefaultHeaders() {
    HashMap<String, String> headers = new HashMap<>()
    return headers;
  }

}
