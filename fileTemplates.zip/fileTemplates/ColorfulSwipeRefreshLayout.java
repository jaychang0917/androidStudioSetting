package ${PACKAGE_NAME};

import android.content.Context;
import android.util.AttributeSet;

public class ColorfulSwipeRefreshLayout extends android.support.v4.widget.SwipeRefreshLayout {

  public ColorfulSwipeRefreshLayout(Context context) {
    super(context);
  }

  public ColorfulSwipeRefreshLayout(Context context, AttributeSet attrs) {
    super(context, attrs);

    setColorSchemeResources(R.color.COLOR_Theme_Green, R.color.COLOR_Yellow_Tab);
  }
}
