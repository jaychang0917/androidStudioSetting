package ${PACKAGE_NAME};

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.jaychang.nrv.RecyclerCell;
import butterknife.BindView;
import butterknife.ButterKnife;

#set ($needCallback = $Callback.equals("t"))
public class ${NAME} extends RecyclerCell {

  private $Model data;
  #if ($needCallback)
  private Callback callback;
  #end
  public ${NAME}($Model data) {
    this.data = data;
  }

  @Override
  public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int pos) {
    View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_, viewGroup, false);
    return new ViewHolder(view);
  }

  @Override
  public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int pos) {
    ViewHolder holder = (ViewHolder) viewHolder;
    Context context = holder.rootView.getContext();
    
    #if ($needCallback)
    if (callback != null) {
      holder.rootView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
          callback.onCellClicked(data);
        }
      });
    }
    #end
    
  }
  #if ($needCallback)
  public void setCallback(Callback callback) {
    this.callback = callback;
  }
  #end
  static class ViewHolder extends RecyclerView.ViewHolder {
    View rootView;

    ViewHolder(View itemView) {
      super(itemView);
      rootView = itemView;
      ButterKnife.bind(this, itemView);
    }
  }
  #if ($needCallback)
  public interface Callback {
    void onCellClicked(Contributor contributor);
  }
  #end
}
