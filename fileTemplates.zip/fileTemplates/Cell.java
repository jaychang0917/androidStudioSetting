package ${PACKAGE_NAME};

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.jaychang.nrv.RecyclerCell;
import butterknife.BindView;
import butterknife.ButterKnife;

#set ($needCallback = $Callback.equals("y"))
#set ($data = $Model.toLowerCase())
public class ${NAME} extends BaseCell {

  private $Model $data;
  #if ($needCallback)
  private Callback callback;
  #end
  public ${NAME}($Model $data) {
    this.$data = $data;
  }

  @Override
  public BaseViewHolder onCreateViewHolder(ViewGroup viewGroup, int position) {
    View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell, viewGroup, false);
    return new ViewHolder(view);
  }

  @Override
  public void onBindViewHolder(BaseViewHolder viewHolder, int position, View.OnTouchListener handleTouchListener) {
    ViewHolder holder = (ViewHolder) viewHolder;
    Context context = holder.rootView.getContext();
    
    #if ($needCallback)
    if (callback != null) {
      holder.rootView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
          callback.onCellClicked($data);
        }
      });
    }
    #end
    
  }
  #if ($needCallback)
  public void setCallback(Callback callback) {
    this.callback = callback;
  }
  #end
  static class ViewHolder extends BaseViewHolder {
    View rootView;

    ViewHolder(View itemView) {
      super(itemView);
      rootView = itemView;
      ButterKnife.bind(this, itemView);
    }
  }
  #if ($needCallback)
  public interface Callback {
    void onCellClicked($Model $data);
  }
  #end
}
