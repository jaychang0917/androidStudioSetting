package ${PACKAGE_NAME};

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.f2prateek.dart.Dart;
import com.f2prateek.dart.InjectExtra;

import butterknife.BindView;
import butterknife.ButterKnife;
import uk.co.senab.photoview.PhotoView;
import uk.co.senab.photoview.PhotoViewAttacher;

public class ${NAME} extends AppCompatActivity {

  @BindView(R.id.photoView)
  PhotoView photoView;

  public static final String EXTRA_IMAGE_URL = "EXTRA_IMAGE_URL";

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_);
    ButterKnife.bind(this);

    String imageUrl = getIntent().getStringExtra(EXTRA_IMAGE_URL);
    Glide.with(this)
      .load(imageUrl)
      .thumbnail(0.1f)
      .into(photoView);

    PhotoViewAttacher mAttacher = new PhotoViewAttacher(photoView);
    mAttacher.update();
  }
}
