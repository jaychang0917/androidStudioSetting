package ${PACKAGE_NAME};

import com.google.gson.Gson;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.rsl.butterfly.data.model.YoutubeVideo;

import java.lang.reflect.Type;

public class ${NAME} implements JsonDeserializer<${Model}> {
  @Override
  public ${Model} deserialize(final JsonElement src, final Type srcType,
                         final JsonDeserializationContext context) throws JsonParseException {
    return new Gson().fromJson(src.getAsString(), ${Model}.class);
  }
}