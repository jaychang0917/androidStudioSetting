package ${PACKAGE_NAME}

import android.content.Context
import android.support.v4.view.ViewPager
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.jaychang.extensions.util.dpToPx

class VerticalViewPager : ViewPager {
  constructor(context: Context) : super(context) {
    init()
  }

  constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
    init()
  }

  private fun init() {
    setPageTransformer(true, VerticalPageTransformer())
    overScrollMode = View.OVER_SCROLL_NEVER

    // change scroll page threshold
    val clazz = javaClass.superclass
    val flingField = clazz.getDeclaredField("mMinimumVelocity")
    flingField.isAccessible = true
    flingField.setInt(this, dpToPx(50))
  }

  private inner class VerticalPageTransformer : ViewPager.PageTransformer {
    override fun transformPage(view: View, position: Float) {
      view.setLayerType(View.LAYER_TYPE_NONE, null);
      println("position: $position view height: ${view.height}")
      if (position < -1) { // [-Infinity,-1)
        // This page is way off-screen to the left.
        view.alpha = 0f

      } else if (position <= 1) { // [-1,1]
        view.alpha = 1f

        // Counteract the default slide transition
        view.translationX = view.width * -position

        //set Y position to swipe in from top
        val yPosition = position * view.height
        view.translationY = yPosition

      } else { // (1,+Infinity]
        // This page is way off-screen to the right.
        view.alpha = 0f
      }
    }
  }

  private fun swapXY(ev: MotionEvent): MotionEvent {
    val width = width.toFloat()
    val height = height.toFloat()

    val newX = ev.y / height * width
    val newY = ev.x / width * height

    ev.setLocation(newX, newY)

    return ev
  }

  override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
    val intercepted = super.onInterceptTouchEvent(swapXY(ev))
    swapXY(ev)
    return intercepted
  }
  
  override fun onTouchEvent(ev: MotionEvent): Boolean {
    return super.onTouchEvent(swapXY(ev))
  }
}