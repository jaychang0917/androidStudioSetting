package ${PACKAGE_NAME}

import android.content.Context
import android.support.design.widget.BottomSheetBehavior
import android.support.design.widget.BottomSheetDialog
import android.view.LayoutInflater
import android.view.View

class ${NAME} : BottomSheetDialog {

  private var behavior: BottomSheetBehavior<View>

  constructor(context: Context) : super(context) {
    val contentView = LayoutInflater.from(context).inflate(R.layout.view_dialog, null)
    setContentView(contentView)
    behavior = BottomSheetBehavior.from(contentView.parent as View)
  }

  fun expand() {
    behavior.state = BottomSheetBehavior.STATE_EXPANDED
  }

  fun collapse() {
    behavior.state = BottomSheetBehavior.STATE_COLLAPSED
  }

}