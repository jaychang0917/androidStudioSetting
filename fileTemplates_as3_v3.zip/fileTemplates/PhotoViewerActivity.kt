package ${PACKAGE_NAME}

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.view.View
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.github.chrisbanes.photoview.PhotoViewAttacher
import com.jaychang.utils.AppUtils
import kotlinx.android.synthetic.main.activity_photo_viewer.*
import java.io.File

class ${NAME} : BaseActivity() {

  companion object {
    val IMAGE_URL = "IMAGE_URL"
    private val CODE_STORAGE_PERMISSION = 1
    private val PERMISSION_EXTERNAL_STORAGE = Manifest.permission.WRITE_EXTERNAL_STORAGE
  }

  lateinit var imageUrl: String

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_photo_viewer)

    imageUrl = intent.getStringExtra(IMAGE_URL)

    Glide.with(this)
      .load(imageUrl)
      .thumbnail(0.1f)
      .into(photoView)

    PhotoViewAttacher(photoView).update()
    
    toolbar.setLeftIconOnClickListener { finish() }
  }

  fun downloadPhotoIfHavePermission(view: View) {
    if (ContextCompat.checkSelfPermission(this, PERMISSION_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
      downloadPhoto()
    } else {
      ActivityCompat.requestPermissions(this, arrayOf(PERMISSION_EXTERNAL_STORAGE), CODE_STORAGE_PERMISSION)
    }
  }
  
  override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
    if (requestCode == CODE_STORAGE_PERMISSION && grantResults.isNotEmpty()
      && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
      downloadPhoto()
    }
  }

  private fun downloadPhoto() {
    Glide.with(this)
      .load(imageUrl)
      .downloadOnly(object : SimpleTarget<File>() {
        override fun onResourceReady(resource: File, transition: Transition<in File>?) {
          AppUtils.saveImageToAlbum(this@PhotoViewerActivity, resource, {
            
          })
        }
      })
  }

}