package ${PACKAGE_NAME}

class ${NAME} : BaseActivity() {

  companion object {
    private val LOCATION_PERMISSION = Manifest.permission.ACCESS_FINE_LOCATION
    private val CODE_LOCATION_PERMISSION = 1
    private val DEFAULT_MAP_ZOOM = 12f
    private val DEFAULT_LOCATION = LatLng(22.2824673, 114.1615726)
  }

  lateinit var googleMap: GoogleMap
  var isMapInited = false

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.your_layout)
    requestPermissionIfNeed()
  }

  fun requestPermissionIfNeed() {
    if (ContextCompat.checkSelfPermission(this, LOCATION_PERMISSION) == PackageManager.PERMISSION_GRANTED) {
      setupMapViewIfNeed()
    } else {
      ActivityCompat.requestPermissions(this, arrayOf(LOCATION_PERMISSION), CODE_LOCATION_PERMISSION)
    }
  }

  override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
    if (requestCode == CODE_LOCATION_PERMISSION && grantResults.isNotEmpty()
      && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
      setupMapViewIfNeed()
    }
  }

  @SuppressLint("MissingPermission")
  fun setupMapViewIfNeed() {
    if (isMapInited) {
      reloadMapView()
      return
    }

    val mapFragment = supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
    mapFragment.getMapAsync { map ->
      googleMap = map
      map.uiSettings.isMapToolbarEnabled = false
      map.uiSettings.isMyLocationButtonEnabled = true
      map.isMyLocationEnabled = true

      map.moveCamera(CameraUpdateFactory.newLatLngZoom(DEFAULT_LOCATION, DEFAULT_MAP_ZOOM))

      map.setOnMarkerClickListener(this)

      reloadMapView()

      isMapInited = true
    }
  }
  
  override fun onMarkerClick(marker: Marker) {
    
  }

  fun reloadMapView() {
    val region = googleMap.projection.visibleRegion
    val northEast = region.farRight
    val center = googleMap.cameraPosition.target
    val radius = SphericalUtil.computeDistanceBetween(center, northEast)
    // todo load api
  }
  
  fun bindMapMarkers(data: List<Object>) {
    googleMap.addMarker(MarkerOptions().position(MELBOURNE).icon(BitmapDescriptorFactory.fromResource(R.drawable.marker)));
  }

}