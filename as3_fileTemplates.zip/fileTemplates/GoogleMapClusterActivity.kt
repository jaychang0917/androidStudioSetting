package ${PACKAGE_NAME}

class MarkerItem(val aPosition: LatLng, val data: Object) : ClusterItem {
  override fun getSnippet(): String = ""
  override fun getTitle(): String = ""
  override fun getPosition(): LatLng = aPosition
}

class ${NAME} : BaseActivity(),
  ClusterManager.OnClusterClickListener<MarkerItem>,
  ClusterManager.OnClusterItemClickListener<MarkerItem> {

  companion object {
    val LOCATION_PERMISSION = Manifest.permission.ACCESS_FINE_LOCATION
    val CODE_LOCATION_PERMISSION = 1
    val MIN_CLUSTER_SIZE = 10
    val DEFAULT_MAP_ZOOM = 12f
    val DEFAULT_LOCATION = LatLng(22.2824673, 114.1615726)
  }

  lateinit var googleMap: GoogleMap
  var isMapInited = false
  lateinit var clusterManager: ClusterManager<MarkerItem>
  lateinit var render: ClusterRenderer
  var selectedMarker: Marker? = null
  var isClustersChanged = false

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.your_layout)
    requestPermissionIfNeed()
  }

  fun requestPermissionIfNeed() {
    if (ContextCompat.checkSelfPermission(this, LOCATION_PERMISSION) == PackageManager.PERMISSION_GRANTED) {
      setupMapViewIfNeed()
    } else {
      ActivityCompat.requestPermissions(this, arrayOf(LOCATION_PERMISSION), CODE_LOCATION_PERMISSION)
    }
  }

  override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
    if (requestCode == CODE_LOCATION_PERMISSION && grantResults.isNotEmpty()
      && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
      setupMapViewIfNeed()
    }
  }

  @SuppressLint("MissingPermission")
  fun setupMapViewIfNeed() {
    if (isMapInited) {
      reloadMapView()
      return
    }

    val mapFragment = supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
    mapFragment.getMapAsync { map ->
      googleMap = map
      map.uiSettings.isMapToolbarEnabled = false
      map.uiSettings.isMyLocationButtonEnabled = true
      map.isMyLocationEnabled = true

      map.moveCamera(CameraUpdateFactory.newLatLngZoom(DEFAULT_LOCATION, DEFAULT_MAP_ZOOM))

      clusterManager = ClusterManager(this, map)
      clusterManager.setOnClusterClickListener(this)
      clusterManager.setOnClusterItemClickListener(this)
      render = ClusterRenderer()
      render.minClusterSize = MIN_CLUSTER_SIZE
      clusterManager.renderer = render
      map.setOnCameraIdleListener(clusterManager)
      map.setOnMarkerClickListener(clusterManager)

      reloadMapView()

      isMapInited = true
    }
  }

  fun reloadMapView() {
    val region = googleMap.projection.visibleRegion
    val northEast = region.farRight
    val center = googleMap.cameraPosition.target
    val radius = SphericalUtil.computeDistanceBetween(center, northEast)
    // todo load api
  }
  
  fun bindMapMarkers(data: List<Object>) {
    clusterManager.clearItems()
    val markerItems = data.map { MarkerItem(LatLng(it.location.lat, it.location.lon), it) }
    clusterManager.addItems(markerItems)
    clusterManager.cluster()
  }

  override fun onClusterClick(cluster: Cluster<MarkerItem>): Boolean {
    deselectPreviousMarker(cluster.size)
    val marker = render.getMarker(cluster)
    marker.setIcon(makeIconWithText(R.drawable.btn_map_pin_2_on, cluster.size))
    selectedMarker = marker
    val data = cluster.items.map { it.data }
    return false
  }

  override fun onClusterItemClick(markerItem: MarkerItem): Boolean {
    deselectPreviousMarker()
    val marker = render.getMarker(markerItem)
    marker.setIcon(makeIcon(R.drawable.btn_map_pin_on))
    selectedMarker = marker
    return false
  }

  fun deselectPreviousMarker(clusterSize: Int? = null) {
    selectedMarker?.let {
      if (isClustersChanged) {
        isClustersChanged = false
        return@let
      }
      if (clusterSize != null) {
        it.setIcon(makeIconWithText(R.drawable.btn_map_pin_2_off, clusterSize))
      } else {
        it.setIcon(makeIcon(R.drawable.btn_map_pin_off))
      }
    }
  }

  fun makeIconWithText(icon: Int, count: Int): BitmapDescriptor {
    val text = if (count > MIN_CLUSTER_SIZE) "$MIN_CLUSTER_SIZE+" else "$count"
    val icon = ImageUtils.drawableToBitmap(this, icon).withText(this, text)
    return BitmapDescriptorFactory.fromBitmap(icon)
  }

  fun makeIcon(icon: Int): BitmapDescriptor {
    return BitmapDescriptorFactory.fromResource(icon)
  }

  inner class ClusterRenderer : DefaultClusterRenderer<MarkerItem>(this, googleMap, clusterManager) {
    override fun onBeforeClusterItemRendered(item: MarkerItem, markerOptions: MarkerOptions) {
      markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.btn_map_pin_off))
    }

    override fun onBeforeClusterRendered(cluster: Cluster<MarkerItem>, markerOptions: MarkerOptions) {
      markerOptions.icon(makeIconWithText(R.drawable.btn_map_pin_2_off, cluster.size))
    }

    override fun onClustersChanged(clusters: MutableSet<out Cluster<MarkerItem>>) {
      super.onClustersChanged(clusters)
      isClustersChanged = clusters.any { it.items.size > 1 }
    }
  }
}