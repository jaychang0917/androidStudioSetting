package ${PACKAGE_NAME}

import android.Manifest
import android.os.Bundle
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.github.chrisbanes.photoview.PhotoViewAttacher
import com.jaychang.utils.AppUtils
import com.tbruyelle.rxpermissions2.RxPermissions
import kotlinx.android.synthetic.main.activity_photo_viewer.*
import org.jetbrains.anko.toast
import java.io.File

class ${NAME} : BaseActivity() {

  companion object {
    val IMAGE_URL : String= "IMAGE_URL"
  }

  lateinit var imageUrl: String

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_photo_viewer)

    imageUrl = intent.getStringExtra(IMAGE_URL)

    Glide.with(this)
      .load(imageUrl)
      .thumbnail(0.1f)
      .into(photoView)

    PhotoViewAttacher(photoView).update()
    
    toolbar.setLeftIconOnClickListener { finish() }
  }

  fun downloadPhotoIfHavePermission() {
    RxPermissions(this)
      .request(Manifest.permission.WRITE_EXTERNAL_STORAGE)
      .subscribe { granted ->
        if (granted) {
          downloadPhoto()
        }
      }
  }

  private fun downloadPhoto() {
    Glide.with(this)
      .load(imageUrl)
      .downloadOnly(object : SimpleTarget<File>() {
        override fun onResourceReady(resource: File?, transition: Transition<in File>?) {
          AppUtils.saveImageToAlbum(this@PhotoViewerActivity, resource!!, {
            
          })
        }
      })
  }

}