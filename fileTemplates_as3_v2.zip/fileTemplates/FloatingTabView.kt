package ${PACKAGE_NAME}

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.PaintDrawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import com.jaychang.utils.AppUtils

class FloatingTabView : FrameLayout {

  companion object {
    private val NORMAL_COLOR = Color.parseColor("#3f003459")
    private val SELECTED_COLOR = Color.parseColor("#003459")
    private val SELECTED_TAB_INSET = 4
  }

  private var tabViews = mutableListOf<TextView>()
  private val floatingView = View(context)
  private var tabWidth = 0
  private var badgeViews = mutableListOf<View>()
  private var isInitialized = false
  private var badgePosition = -1
  private var badgeVisibility = View.GONE
  
  var selectedIndex = 0
  var tabs = listOf<String>()
  var onTabChangedListener: ((Int) -> Unit)? = null

  constructor(ctx: Context) : this(ctx, null, 0)
  constructor(ctx: Context, attrs: AttributeSet?) : this(ctx, attrs, 0)
  constructor(ctx: Context, attrs: AttributeSet?, defaultStyle: Int) : super(ctx, attrs, defaultStyle) {
    background = getRoundDrawable("#19003459", 4)
  }

  private fun addViews() {
    removeAllViews()
    tabViews.clear()

    val height = dp(36)
    floatingView.background = getRoundDrawable("#ffffff", 6)
    val selectedViewInset = dp(SELECTED_TAB_INSET)
    val selectedViewLayoutParams = FrameLayout.LayoutParams(tabWidth - selectedViewInset, height - selectedViewInset * 2)
    floatingView.layoutParams = selectedViewLayoutParams
    floatingView.x = selectedViewInset.toFloat()
    floatingView.y = selectedViewInset.toFloat()

    addView(floatingView)

    var currentX = 0f
    for (tab in tabs) {
      val view = buildTabView(tab)
      val index = tabs.indexOf(tab)
      val layoutParams = FrameLayout.LayoutParams(tabWidth, height)
      view.layoutParams = layoutParams
      view.tag = index
      view.setOnClickListener {
        selectedIndex = index
        updateUI()
        onTabChangedListener?.invoke(selectedIndex)
      }
      view.x = currentX
      view.y = 0f
      currentX += tabWidth
      addView(view)
      tabViews.add(view)

      // add badge view
      val textBound = Rect()
      view.paint.getTextBounds(tab, 0, tab.length, textBound)
      val adjustment = dp(1)
      val badgeX = (tabWidth - textBound.width()) / 2 + textBound.width() + adjustment
      val badgeY = (height - textBound.height()) / 2 - adjustment
      val badgeOffset = index * tabWidth
      val badgeView = buildBadgeView(badgeX + badgeOffset, badgeY)
      badgeView.visibility = View.GONE
      addView(badgeView)
      badgeViews.add(badgeView)
    }

    tabViews[0].setTextColor(SELECTED_COLOR)

    isInitialized = true
  }

  override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
    super.onMeasure(widthMeasureSpec, heightMeasureSpec)

    val width = MeasureSpec.getSize(widthMeasureSpec)
    tabWidth = width / tabs.size

    if (!isInitialized) {
      addViews()
    }
  }

  private fun buildTabView(tab: String): TextView {
    val view = TextView(context)
    view.text = tab
    view.gravity = Gravity.CENTER
    view.setTextColor(NORMAL_COLOR)
    view.textSize = 15f
    return view
  }

  private fun buildBadgeView(x: Int, y: Int): View {
    val view = View(context)
    view.x = x.toFloat()
    view.y = y.toFloat()
    val layoutParams = FrameLayout.LayoutParams(dp(8), dp(8))
    view.layoutParams = layoutParams
    view.background = getRoundDrawable("#ea4853", 4)
    return view
  }

  private fun updateUI() {
    val offset = if (selectedIndex == 0) dp(SELECTED_TAB_INSET) else 0
    val newX = selectedIndex * tabWidth + offset
    floatingView.animate().setDuration(300).x(newX.toFloat()).start()
    for (tabView in tabViews) {
      if (tabView.tag == selectedIndex) {
        tabView.setTextColor(SELECTED_COLOR)
      } else {
        tabView.setTextColor(NORMAL_COLOR)
      }
    }
  }

  override fun onDraw(canvas: Canvas?) {
    super.onDraw(canvas)
    if (badgePosition != -1) {
      badgeViews[badgePosition].visibility = badgeVisibility
    }
  }

  fun showBadge(position: Int) {
    badgePosition = position
    badgeVisibility = View.VISIBLE
    invalidate()
  }

  fun hideBadge(position: Int) {
    badgePosition = position
    badgeVisibility = View.GONE
    invalidate()
  }

  private fun dp(dp: Int) = AppUtils.dp2px(context, dp)

  private fun getRoundDrawable(color: String, radius: Int): PaintDrawable {
    val drawable = PaintDrawable(Color.parseColor(color))
    drawable.setCornerRadius(dp(radius).toFloat())
    return drawable
  }

}