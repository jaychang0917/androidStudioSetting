package ${PACKAGE_NAME}

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.DialogInterface
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.ImageButton
import org.jetbrains.anko.alert
import org.jetbrains.anko.cancelButton
import org.jetbrains.anko.indeterminateProgressDialog
import org.jetbrains.anko.okButton

open class BaseActivity: AppCompatActivity() {

  var loadingDialog: ProgressDialog? = null

  override fun onPostCreate(savedInstanceState: Bundle?) {
    super.onPostCreate(savedInstanceState)
    setBackIconClickEvent()
  }

  private fun setBackIconClickEvent() {
    val leftIcon = findViewById<ImageButton>(R.id.leftIcon)
    val isBackIcon = leftIcon != null && leftIcon.drawable?.constantState == getDrawable(android.R.drawable.star_off).constantState
    if (isBackIcon) {
      leftIcon.setOnClickListener {
        finish()
      }
    }
  }

  fun showMessageDialog(message: String, title: String? = null, okButtonClickListener: (()->Unit)? = null) {
    alert(message, title) {
      okButton { okButtonClickListener?.invoke() }
      cancelButton {  }
    }.show()
  }

  fun showLoadingDialog() {
    loadingDialog = indeterminateProgressDialog("Loading...")
    loadingDialog?.show()
  }

  fun hideLoadingDialog() {
    loadingDialog?.dismiss()
  }

  fun showItemsDialog(title: String? = null, items: Array<String>, listener: ((DialogInterface, Int)->Unit)? = null) {
    AlertDialog.Builder(this)
      .setTitle(title)
      .setItems(items, listener)
      .show()
  }

  fun showMultiChoiceDialog(title: String? = null, items: Array<String>, selectedItems: BooleanArray, listener: ((DialogInterface, Int, Boolean)->Unit)? = null) {
    AlertDialog.Builder(this)
      .setTitle(title)
      .setMultiChoiceItems(items, selectedItems, listener)
      .show()
  }

  fun showSingleChoiceDialog(title: String? = null, items: Array<String>, checkedItem: Int, listener: ((DialogInterface, Int)->Unit)? = null) {
    AlertDialog.Builder(this)
      .setTitle(title)
      .setSingleChoiceItems(items, checkedItem, listener)
      .show()
  }

}