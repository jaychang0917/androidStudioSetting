package ${PACKAGE_NAME}

import android.net.http.SslError
import android.os.Bundle
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import com.mindbeauty.app.R
import kotlinx.android.synthetic.main.activity_webpage.*

class WebPageActivity : BaseActivity() {

  companion object {
    val WEB_URL = "WEB_URL"
  }

  lateinit var url: String

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_webpage)
    url = intent.getStringExtra(WEB_URL)
    webView.settings.javaScriptEnabled = true
    webView.webViewClient = object : WebViewClient() {
      override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
        handler.proceed()
      }
    }
    webView.loadUrl(url)
  }
}
