package ${PACKAGE_NAME}

import android.content.Context
import android.util.AttributeSet
import android.widget.ImageView
import android.widget.LinearLayout
import com.jaychang.utils.AppUtils

abstract class RatingView : LinearLayout {

  abstract var normalIcon: Int
  abstract var selectedIcon: Int
  abstract var maxCount: Int

  constructor(ctx: Context) : this(ctx, null, 0)
  constructor(ctx: Context, attrs: AttributeSet?) : super(ctx, attrs, 0)
  constructor(ctx: Context, attrs: AttributeSet?, defaultStyle: Int) : super(ctx, attrs, defaultStyle) {
    init()
  }

  private fun init() {
    orientation = HORIZONTAL
  }

  fun configure(count: Int,
                size: Int = 12,
                isSelectable: Boolean = false,
                padding: Int = 2) {
    addViews(count, size, isSelectable, padding)
  }

  private fun select(count: Int) {
    for (index in 0 until childCount) {
      val view = getChildAt(index) as ImageView
      view.setImageResource(normalIcon)
    }

    for (index in 0 until count) {
      val view = getChildAt(index) as ImageView
      view.setImageResource(selectedIcon)
    }
  }
  private fun addViews(count: Int,
                       size: Int,
                       isSelectable: Boolean,
                       padding: Int) {
    removeAllViews()

    for (index in 0 until count) {
      val starView = ImageView(context)
      starView.setImageResource(selectedIcon)
      starView.scaleType = ImageView.ScaleType.CENTER_CROP
      addView(starView, size, padding)
    }

    for (index in 0 until maxCount - count) {
      val starView = ImageView(context)
      starView.setImageResource(normalIcon)
      starView.scaleType = ImageView.ScaleType.CENTER_CROP
      addView(starView, size, padding)
    }

    if (isSelectable) {
      for (index in 0 until maxCount) {
        getChildAt(index).setOnClickListener {
          select(index + 1)
        }
      }
    }
  }
  private fun addView(view: ImageView, size: Int, padding: Int) {
    val width = AppUtils.dp2px(context, size)
    val layoutParams = MarginLayoutParams(width, width)
    layoutParams.rightMargin = AppUtils.dp2px(context, padding)
    view.layoutParams = layoutParams
    addView(view)
  }

}

class StarRatingView : RatingView {

  override var normalIcon: Int = android.R.drawable.star_off
  override var selectedIcon: Int = android.R.drawable.star_on
  override var maxCount: Int = 5

  constructor(ctx: Context) : this(ctx, null, 0)
  constructor(ctx: Context, attrs: AttributeSet?) : this(ctx, attrs, 0)
  constructor(ctx: Context, attrs: AttributeSet?, defaultStyle: Int) : super(ctx, attrs, defaultStyle)

}
