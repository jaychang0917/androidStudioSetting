package com.hkust.ustinfoday.managers

import android.content.Context
import android.text.TextUtils
import com.jaychang.utils.AppUtils
import com.jaychang.utils.PreferenceUtils
import java.util.*

object PreferenceManager {

  const val CURRENT_LANGUAGE = "CURRENT_LANGUAGE"

  fun hasChangedLang(context: Context) = !TextUtils.isEmpty(PreferenceUtils.getString(context, CURRENT_LANGUAGE))

  fun isTChinese(context: Context) =
    PreferenceUtils.getString(context, CURRENT_LANGUAGE).equals("zh-hant") ||
      (!hasChangedLang(context) && "zh".equals(Locale.getDefault().language))

  fun setToEnglish(context: Context) = PreferenceUtils.saveString(context, CURRENT_LANGUAGE, "en")

  fun setToTChinese(context: Context) = PreferenceUtils.saveString(context, CURRENT_LANGUAGE, "zh-hant")

  fun changeLanguage(context: Context) {
    if (!PreferenceManager.hasChangedLang(context)) {
      return
    }

    if (PreferenceManager.isTChinese(context)) {
      AppUtils.changeLanguage(context, Locale.TRADITIONAL_CHINESE, false)
      PreferenceManager.setToTChinese(context)
    } else {
      AppUtils.changeLanguage(context, Locale.ENGLISH, false)
      PreferenceManager.setToEnglish(context)
    }
  }

}