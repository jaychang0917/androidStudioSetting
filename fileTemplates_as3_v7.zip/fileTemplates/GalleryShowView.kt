package com.buddigo.buying.app.widgets

import android.content.Context
import android.os.Handler
import android.support.v4.view.PagerAdapter
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import com.buddigo.buying.app.R
import com.buddigo.buying.app.utils.ImageUtils
import kotlinx.android.synthetic.main.view_gallery_show.view.*

// compile 'com.romandanylyk:pageindicatorview:1.0.0'
class GalleryShowView : FrameLayout {
  constructor(ctx: Context) : this(ctx, null, 0)
  constructor(ctx: Context, attrs: AttributeSet?) : this(ctx, attrs, 0)
  constructor(ctx: Context, attrs: AttributeSet?, defaultStyleAttrs: Int) : super(ctx, attrs, defaultStyleAttrs) {
    LayoutInflater.from(ctx).inflate(R.layout.view_gallery_show, this)
    leftArrowView.setOnClickListener {
      val pos = pageIndicatorView.selection - 1
      setPosition(pos)
    }
    rightArrowView.setOnClickListener {
      val pos = pageIndicatorView.selection + 1
      setPosition(pos)
    }
  }

  private fun setPosition(pos: Int) {
    pageIndicatorView.selection = pos
    viewPager.currentItem = pos
  }

  fun setData(data: List<String>) {
    viewPager.adapter = MyAdapter(context, data)
  }

  fun setIsLoop(value: Boolean, delayMillis: Long = 2000L) {
    if (!value) {
      return
    }
    
    Handler().apply {
      val runnable = object : Runnable {
        override fun run() {
          val attempPos = pageIndicatorView.selection + 1
          val pos = if (attempPos >= viewPager.childCount) 0 else { attempPos }
          setPosition(pos)
          postDelayed(this, delayMillis)
        }
      }
      postDelayed(runnable, delayMillis)
    }
  }

  private class MyAdapter(val context: Context, val data: List<String>) : PagerAdapter() {
    var viewList: List<View>

    init {
      viewList = createPageList()
    }

    override fun instantiateItem(collection: ViewGroup, position: Int): Any {
      val view = viewList[position]
      collection.addView(view)
      return view
    }

    override fun destroyItem(collection: ViewGroup, position: Int, view: Any) {
      collection.removeView(view as View)
    }

    override fun getCount(): Int {
      return viewList.size
    }

    override fun isViewFromObject(view: View, obj: Any): Boolean {
      return view === obj
    }

    override fun getItemPosition(`object`: Any?): Int {
      return POSITION_NONE
    }

    private fun createPageList(): List<View> {
      return data.map { createPageView(it) }
    }

    private fun createPageView(url: String): View {
      val view = ImageView(context)
      view.scaleType = ImageView.ScaleType.CENTER_CROP
      ImageUtils.load(url, view)
      return view
    }
  }
}