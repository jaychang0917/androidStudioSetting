package ${PACKAGE_NAME}

import android.content.Context
import android.view.View
import android.view.ViewGroup
import com.jaychang.srv.SimpleCell
import com.jaychang.srv.SimpleViewHolder

class ${NAME}(data: MyModel) : SimpleCell<MyModel, ${NAME}.ViewHolder>(data) {

  override fun onCreateViewHolder(p0: ViewGroup, view: View): ViewHolder = ViewHolder(view)

  override fun getLayoutRes(): Int = R.layout.my_layout

  override fun onBindViewHolder(viewHolder: ViewHolder, position: Int, context: Context, payload: Any?) {
    
  }

  override fun onUnbindViewHolder(holder: ViewHolder) {
    
  }

  class ViewHolder(itemView: View) : SimpleViewHolder(itemView)

}